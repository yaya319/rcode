


# compare the new and old tarrif

data_player=all[all$insurer=="Direct Assurance",]

w1=data_player[data_player$period=="Y16M09"& data_player$insurer=="Direct Assurance",]
w2=data_player[data_player$period=="Y16M09_Mario"& data_player$insurer=="Direct Assurance",]

w12=merge(w1,w2, by=c("profilID","coverage","insurer"))
w12$delta=w12$price.y/w12$price.x-1
w12$delta=round(w12$delta*100,2)

w12=w12[w12$delta<300,]
# #The price difference is delta=w2price/w1price-1 in% : input data of one insurer and period   
# player_delta=price_changes(data_player,target_player,target_player,target_period1, target_period2)

# 
# player_delta=player_delta[player_delta$delta<50,]

summary(w12[w12$coverage=="Basic Coverage",]$delta)
summary(w12[w12$coverage=="Comfortable Coverage",]$delta)
summary(w12[w12$coverage=="PNO",]$delta)

w12_basic=w12[w12$coverage=="Basic Coverage",]
output_summary_csv(w12_basic)
graphics.off()
output_delta_distribution(w12_basic,"Basic Coverage",min(w12_basic$delta),max(w12_basic$delta),40)


w12_com=w12[w12$coverage=="Comfortable Coverage",]
output_summary_csv(w12_com)
graphics.off()
output_delta_distribution(w12_com,"Comfortable Coverage",min(w12_com$delta),max(w12_com$delta),40)

w12_PNO=w12[w12$coverage=="PNO",]
output_summary_csv(w12_PNO)
graphics.off()
output_delta_distribution(w12_PNO,"PNO",min(w12_PNO$delta),max(w12_PNO$delta),40)


# #summary of the delta and output in csv and in graphs and output them
# for (i in 1:length(covfr)){
#   
#   player_delta1=player_delta[player_delta$coverage==covfr[i], ]
#   output_summary(player_delta1)
#   
#   ## output the distribution graphs
#   ## function output_delta_distribution<- function(data,coverage,break1,break2,histogram_break)
#   ## break1: min delta
#   ## break2: max delta
#   ##histogram_break: the breaks numbers
#   
#   output_delta_distribution(player_delta1,covfr[i],min(player_delta1$delta),max(player_delta1$delta),40)
# }

