###############price gap
# calculate price gap
pricegap_global=price_gap(originaldata,month,Name)

### output the graphs
datainput=pricegap_global

graphics.off()

for (k in 1:length(covfr)) {
  histogram_break=5
  
  data1=datainput[datainput$coverage==covfr[k], ]
  data1$delta=100*data1$delta
  summary(data1$delta)
  png(filename=paste(PathNameevol,paste(unique(data1$insurer),covfr[k],unique(data1$period), "Price differences.png",sep="_"),sep="/"),width = 760, height = 700);
  
  h<-hist(data1$delta, col="lightgreen",main="",xlab="")
  
  title(paste("Price Changes Distribution",paste(unique(data1$insurer),covfr[k],sep=" / "),sep="\n"),cex.main =2) 
  
  dev.off ();
  
}

name=Name

print(ggplot() +
        geom_density(aes(x=datainput$delta[datainput$coverage==covfr[1] & datainput$yearmonth==month[1]],y=(..count..)/sum(..count..)),colour="royalblue1",alpha = 1, size=2) +
        geom_density(aes(x=datainput$delta[datainput$coverage==covfr[2]& datainput$yearmonth==month[1]],y=(..count..)/sum(..count..)),colour="tomato", alpha = 1,size=2) +
#         geom_density(aes(x=datainput$delta[datainput$coverage==covfr[1] & datainput$yearmonth==month[2]],y=(..count..)/sum(..count..)),colour="royalblue1",alpha = 0.8, size=1.5) +
#         geom_density(aes(x=datainput$delta[datainput$coverage==covfr[2]& datainput$yearmonth==month[2]],y=(..count..)/sum(..count..)),colour="tomato", alpha = 0.8,size=1.5) +
#         geom_density(aes(x=datainput$delta[datainput$coverage==covfr[1] & datainput$yearmonth==month[3]],y=(..count..)/sum(..count..)),colour="royalblue1",alpha = 1, size=2) +
#         geom_density(aes(x=datainput$delta[datainput$coverage==covfr[2]& datainput$yearmonth==month[3]],y=(..count..)/sum(..count..)),colour="tomato", alpha = 1,size=2) +
#         
        geom_vline(xintercept=0) +
        
        annotate("text", label = paste(covfr[1],month[1], sep=" "),colour= "royalblue1", x = 0.4, y = 0.0028, size=6,alpha = 1) +
        annotate("text", label = paste(covfr[2],month[1],sep=" "),colour= "tomato", x = 0.4,y = 0.0024, size=6,,alpha = 1) +
#         annotate("text", label = paste(covfr[1],month[2], sep=" "),colour= "royalblue1", x = 0.8, y = 0.0020, size=5,alpha = 1) +
#         annotate("text", label = paste(covfr[2],month[2],sep=" "),colour= "tomato", x = 0.8, y = 0.0016, size=5,,alpha = 1) +
#         annotate("text", label = paste(covfr[1],month[3], sep=" "),colour= "royalblue1", x = 0.8, y = 0.0012, size=5,alpha = 1) +
#         annotate("text", label = paste(covfr[2],month[3],sep=" "),colour= "tomato", x = 0.8, y = 0.0008, size=5,,alpha = 1) +
#         
        wt +
        ggtitle(paste(paste(name, "Price Gap to the Minimum Price in Region IDF",sep=" "),sep="\n\n\n")) +
        xlab(label = "")+ 
        ylab(label="% MRP")  + scale_x_continuous(labels = percent, breaks=seq(-10,10,0.2)))

ggsave(paste(PathNameevol,file=paste(name, "CI-DeltaMin-Direct_all_byregion.png",sep=" "),sep="/"),width=16,height=9,dpi=100)

### out put the table of price gap mean  

delta1_left=datainput
delta1_left=na.omit(delta1_left)
sum_last_left1=data.frame("period"=unique(datainput$yearmonth)[1],"coverage"=unique(datainput$coverage), "mean"=0)
# sum_last_left2=data.frame("period"=unique(datainput$yearmonth)[2],"coverage"=unique(datainput$coverage), "mean"=0)
# sum_last_left3=data.frame("period"=unique(datainput$yearmonth)[3],"coverage"=unique(datainput$coverage), "mean"=0)

# sum_last_left=rbind(sum_last_left1,sum_last_left2,sum_last_left3)
sum_last_left=sum_last_left1
sum_last_left[sum_last_left$coverage==covfr[1]&sum_last_left$period==unique(datainput$yearmonth)[1],]$mean=round(mean(delta1_left[delta1_left$coverage==covfr[1]&delta1_left$yearmonth==unique(delta1_left$yearmonth)[1],]$delta)*100)
# sum_last_left[sum_last_left$coverage==covfr[1]&sum_last_left$period==unique(datainput$yearmonth)[2] ,]$mean=round(mean(delta1_left[delta1_left$coverage==covfr[1]& delta1_left$yearmonth==unique(delta1_left$yearmonth)[2],]$delta)*100)
# sum_last_left[sum_last_left$coverage==covfr[1]&sum_last_left$period==unique(datainput$yearmonth)[3] ,]$mean=round(mean(delta1_left[delta1_left$coverage==covfr[1]& delta1_left$yearmonth==unique(delta1_left$yearmonth)[3],]$delta)*100)

sum_last_left[sum_last_left$coverage==covfr[2] &sum_last_left$period==datainput$yearmonth[1] ,]$mean=round(mean(delta1_left[delta1_left$coverage==covfr[2]&delta1_left$yearmonth==unique(delta1_left$yearmonth)[1],]$delta)*100)
# sum_last_left[sum_last_left$coverage==covfr[2]&sum_last_left$period==unique(datainput$yearmonth)[2] ,]$mean=round(mean(delta1_left[delta1_left$coverage==covfr[2] & delta1_left$yearmonth==unique(delta1_left$yearmonth)[2],]$delta)*100)
# sum_last_left[sum_last_left$coverage==covfr[2] &sum_last_left$period==unique(datainput$yearmonth)[3] ,]$mean=round(mean(delta1_left[delta1_left$coverage==covfr[2] & delta1_left$yearmonth==unique(delta1_left$yearmonth)[3],]$delta)*100)

png_new(sum_last_left,PathNameevol,paste("mean", name),600,600)


for (i in 1:length(covfr)){
  datainput1=datainput[datainput$coverage==covfr[i], ]
  out=as.matrix(summary(datainput1$delta))
  colnames(out)="value"
  out=t(out)
  
  write.table(out, paste(PathNameevol,paste(unique(datainput1$coverage), "summary.csv", sep="_"),sep="/"), col.names=TRUE,row.names=FALSE,sep=";",quote=FALSE)
  
}