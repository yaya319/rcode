######################### PPT
reporting_MRH<-PPT.Init(visible=TRUE, method = c("RDCOMClient"), addPres = TRUE)

reporting_MRH<-PPT.AddBlankSlide(reporting_MRH)

PPT.ApplyTemplate(reporting_MRH,file="Z:/Customer Price Optimization/MRH/mapping_table/template2.pptx")

reporting_MRH<-PPT.AddTextSlide(reporting_MRH,title ="1. Top 1 Ranking / Direct Assurance / Basic and Comfortable Coverages", title.fontsize = 20, title.font = NULL)
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNamerank,"Proportion of 1st Ranking by month Direct Assurance-Basic Coverage.png",sep="/"),size= c(60,60,300, 380))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNamerank,"Proportion of 1st Ranking by month Direct Assurance-Comfortable Coverage.png",sep="/"),size=  c(380,60,300,380))

reporting_MRH<-PPT.AddTextSlide(reporting_MRH,title ="2. Direct Assurance Rank Position / Basic and Comfortable Coverage", title.fontsize = 20, title.font = NULL)
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNamerank,"CI-RankingByMonth-Direct Assurance-Basic Coverage.png",sep="/"),size= c(60,60,300, 380))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNamerank,"CI-RankingByMonth-Direct Assurance-Comfortable Coverage.png",sep="/"),size=  c(380,60,300,380))


reporting_MRH<-PPT.AddTextSlide(reporting_MRH,title ="3. Price Gap to Minimum Competitors' price", title.fontsize = 20, title.font = NULL)
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNamerank,"Direct Assurance CI-DeltaMin-Direct_all.png",sep="/"),size= c(30,60,300, 220))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNamerank,"mean Direct AssuranceTable.png",sep="/"),size= c(250,80,140, 120))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNamerank,"Direct Assurance_AcommeAssure_CI-DeltaMin-Direct_all.png",sep="/"),size= c(30,280,300, 220))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNamerank,"mean Direct Assurance AcommeAssureTable.png",sep="/"),size=c(250,300,140, 120))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNamerank,"Direct Assurance_MAAF Assurances_CI-DeltaMin-Direct_all.png",sep="/"),size=  c(350,60,300, 220))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNamerank,"mean Direct Assurance MAAF AssurancesTable.png",sep="/"),size=  c(500,80,140, 120))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNamerank,"Direct Assurance_MMA_CI-DeltaMin-Direct_all.png",sep="/"),size= c(350,280,300, 220))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNamerank,"mean Direct Assurance MMATable.png",sep="/"),size= c(550,300,140, 120))



reporting_MRH<-PPT.AddTextSlide(reporting_MRH,title ="4.1. Price Ranking by Home and Occupy Type Segment / Direct Assurance", title.fontsize = 20, title.font = NULL)
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNameseg,"1st Ranking Proportion by occupanttype_hometype Direct Assurance-Basic Coverage.png",sep="/"),size= c(0,60,360, 340))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNameseg,"1st Ranking Proportion by occupanttype_hometype Direct Assurance-Comfortable Coverage.png",sep="/"),size=  c(360,60,360,340))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNameseg,"nprofiles_occupanttype_Direct AssuranceTable.png",sep="/"),size= c(40,380,240, 120))


reporting_MRH<-PPT.AddTextSlide(reporting_MRH,title ="4.2. Price Ranking by Rooms Below40m2 Number Segment / Direct Assurance", title.fontsize = 20, title.font = NULL)
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNameseg,"1st Ranking Proportion by roomsbelow40m2 Direct Assurance-Basic Coverage.png",sep="/"),size= c(10,60,360, 360))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNameseg,"1st Ranking Proportion by roomsbelow40m2 Direct Assurance-Comfortable Coverage.png",sep="/"),size=  c(360,60,360,360))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNameseg,"nprofiles_roomsbelow40m2_Direct AssuranceTable.png",sep="/"),size= c(40,380,240, 120))


reporting_MRH<-PPT.AddTextSlide(reporting_MRH,title ="4.3. Price Ranking by Region Segment / Direct Assurance", title.fontsize = 20, title.font = NULL)
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNameseg,"1st Ranking Proportion by region Direct Assurance-Basic Coverage.png",sep="/"),size= c(0,60,360, 340))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNameseg,"1st Ranking Proportion by region Direct Assurance-Comfortable Coverage.png",sep="/"),size=  c(360,60,360,340))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNameseg,"nprofiles_region_Direct AssuranceTable.png",sep="/"),size= c(40,380,240, 120))



### BNP Natio
reporting_MRH<-PPT.AddTextSlide(reporting_MRH,title ="1. Top 1 Ranking / BNP Natio / Basic and Comfortable Coverages", title.fontsize = 20, title.font = NULL)
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNamerank,"Proportion of 1st Ranking by month BNP Natio-Basic Coverage.png",sep="/"),size= c(60,60,300, 380))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNamerank,"Proportion of 1st Ranking by month BNP Natio-Comfortable Coverage.png",sep="/"),size=  c(380,60,300,380))


reporting_MRH<-PPT.AddTextSlide(reporting_MRH,title ="2. BNP Natio Rank Position / Basic and Comfortable Coverage", title.fontsize = 20, title.font = NULL)
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNamerank,"CI-RankingByMonth-BNP Natio-Basic Coverage.png",sep="/"),size= c(60,60,300, 380))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNamerank,"CI-RankingByMonth-BNP Natio-Comfortable Coverage.png",sep="/"),size=  c(380,60,300,380))


reporting_MRH<-PPT.AddTextSlide(reporting_MRH,title ="3. Price Gap Competitors' price", title.fontsize = 20, title.font = NULL)
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNamerank,"BNP Natio CI-DeltaMin-Direct_all.png",sep="/"),size= c(30,60,300, 220))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNamerank,"mean BNP NatioTable.png",sep="/"),size=c(250,80,140, 120))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNamerank,"BNP Natio_MAAF Assurances_CI-DeltaMin-Direct_all.png",sep="/"),size= c(30,280,300, 220))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNamerank,"mean BNP Natio MAAF AssurancesTable.png",sep="/"),size= c(250,300,140, 120))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNamerank,"BNP Natio_MMA_CI-DeltaMin-Direct_all.png",sep="/"),size=  c(350,60,300, 220))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNamerank,"mean BNP Natio MMATable.png",sep="/"),size=  c(500,80,140, 120))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNamerank,"BNP Natio_AcommeAssure_CI-DeltaMin-Direct_all.png",sep="/"),size= c(350,280,300, 220))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNamerank,"mean BNP Natio AcommeAssureTable.png",sep="/"),size=  c(500,300,140, 120))


reporting_MRH<-PPT.AddTextSlide(reporting_MRH,title ="4.1. Price Ranking by Home and Occupy Type Segment / BNP Natio", title.fontsize = 20, title.font = NULL)
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNameseg,"1st Ranking Proportion by occupanttype_hometype BNP Natio-Basic Coverage.png",sep="/"),size= c(0,60,360, 340))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNameseg,"1st Ranking Proportion by occupanttype_hometype BNP Natio-Comfortable Coverage.png",sep="/"),size=  c(360,60,360,340))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNameseg,"nprofiles_occupanttype_BNP NatioTable.png",sep="/"),size= c(40,380,240, 120))


reporting_MRH<-PPT.AddTextSlide(reporting_MRH,title ="4.2. Price Ranking by Rooms Below40m2 Number Segment / BNP Natio", title.fontsize = 20, title.font = NULL)
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNameseg,"1st Ranking Proportion by roomsbelow40m2 BNP Natio-Basic Coverage.png",sep="/"),size= c(10,60,360, 360))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNameseg,"1st Ranking Proportion by roomsbelow40m2 BNP Natio-Comfortable Coverage.png",sep="/"),size=  c(360,60,360,360))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNameseg,"nprofiles_roomsbelow40m2_BNP NatioTable.png",sep="/"),size= c(40,380,240, 120))


reporting_MRH<-PPT.AddTextSlide(reporting_MRH,title ="4.3. Price Ranking by Region Segment / BNP Natio", title.fontsize = 20, title.font = NULL)
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNameseg,"1st Ranking Proportion by region BNP Natio-Basic Coverage.png",sep="/"),size= c(0,60,360, 340))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNameseg,"1st Ranking Proportion by region BNP Natio-Comfortable Coverage.png",sep="/"),size=  c(360,60,360,340))
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNameseg,"nprofiles_region_BNP NatioTable.png",sep="/"),size= c(40,380,240, 120))

### price gap


### cumulated evolution 

reporting_MRH<-PPT.AddTextSlide(reporting_MRH,title ="ANNEXE: Cumulated evolution: Basic Coverage", title.fontsize = 20, title.font = NULL)
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNameCEBP,"Clog_DIRECTPlayers_Basic Coverage.png",sep="/"),size= c(10,100, 700, 400))

reporting_MRH<-PPT.AddTextSlide(reporting_MRH,title ="ANNEXE: Cumulated evolution: Confortable Coverage", title.fontsize = 20, title.font = NULL)
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNameCEBP,"Clog_DIRECTPlayers_Comfortable Coverage.png",sep="/"),size= c(10,100, 700, 400))


## display
reporting_MRH<-PPT.AddTextSlide(reporting_MRH,title ="ANNEXE: Display Rate: Basic Coverage", title.fontsize = 20, title.font = NULL)
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNameDE,"TRDDISPRATE_DIRECTPlayers_Basic Coverage.png",sep="/"),size= c(10,100, 700, 400))

reporting_MRH<-PPT.AddTextSlide(reporting_MRH,title ="ANNEXE: Display Rate: Confortable Coverage", title.fontsize = 20, title.font = NULL)
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNameDE,"TRDDISPRATE_DIRECTPlayers_Comfortable Coverage.png",sep="/"),size= c(10,100, 700, 400))

## average premium
reporting_MRH<-PPT.AddTextSlide(reporting_MRH,title ="ANNEXE: Average Premium: Basic Coverage", title.fontsize = 20, title.font = NULL)
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNameAPE,"AVGPREMIUM_DIRECTPlayers_Basic Coverage.png",sep="/"),size= c(10,100, 700, 400))

reporting_MRH<-PPT.AddTextSlide(reporting_MRH,title ="ANNEXE: Average Premium: Confortable Coverage", title.fontsize = 20, title.font = NULL)
reporting_MRH<-PPT.AddGraphicstoSlide(reporting_MRH,file=paste(PathNameAPE,"AVGPREMIUM_DIRECTPlayers_Comfortable Coverage.png",sep="/"),size= c(10,100, 700, 400))


