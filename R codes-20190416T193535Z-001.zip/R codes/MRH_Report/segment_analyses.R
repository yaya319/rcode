####### ranking by segments######################

## take only matrix in 201507: this was loaded in the data prepartion step
matrix_HOME=matrix_HOME[grepl("MRH201507",matrix_HOME$profil_id),]

## three segments
# -  OccupantType+home
# -  RoomsBelow40m2
# BNP DirectionRegionale 


################ owner * house type#####################

## find the hometype and occupant type for each profile 
ASSURLAND_HOME_DA_BNP1$hometype=matrix_HOME$hometype[match(ASSURLAND_HOME_DA_BNP1$profilID,matrix_HOME$profil_id)]
ASSURLAND_HOME_DA_BNP1$occupanttype=matrix_HOME$occupanttype[match(ASSURLAND_HOME_DA_BNP1$profilID,matrix_HOME$profil_id)]

##mapping for hometype 
ASSURLAND_HOME_DA_BNP1$hometype=ifelse(ASSURLAND_HOME_DA_BNP1$hometype==1,"Flat",ifelse(ASSURLAND_HOME_DA_BNP1$hometype==2,"House", ""))
table(ASSURLAND_HOME_DA_BNP1$hometype)

##mapping for occupant type
ASSURLAND_HOME_DA_BNP1$occupanttype=ifelse(ASSURLAND_HOME_DA_BNP1$occupanttype==1,"Owner",ifelse(ASSURLAND_HOME_DA_BNP1$occupanttype==2,"Tenant", 
 ifelse(ASSURLAND_HOME_DA_BNP1$occupanttype==3,"Tenant", ifelse(ASSURLAND_HOME_DA_BNP1$occupanttype==4,"InoccupantOwner",""))))
table(ASSURLAND_HOME_DA_BNP1$occupanttype)

## creat segment home type * occupant type
ASSURLAND_HOME_DA_BNP1$occupanttype_hometype=paste(ASSURLAND_HOME_DA_BNP1$occupanttype,ASSURLAND_HOME_DA_BNP1$hometype)
unique(ASSURLAND_HOME_DA_BNP1$occupanttype_hometype)

## keep only useful varaiables
ASSURLAND_HOME_DA_occupanttype_hometype=subset(ASSURLAND_HOME_DA_BNP1,select=c(profilID, insurer,period,coverage,price,occupanttype_hometype))
## renames all the variables
names(ASSURLAND_HOME_DA_occupanttype_hometype)=c("profilID", "insurer","period","coverage","price","segment")

## find the top1 profile by segment
all_home3_occupanttype_hometype_top1=top1propor_segment(ASSURLAND_HOME_DA_occupanttype_hometype)

## calculate the top1 proportion
all_home3_occupanttype_hometype_top1$proportion=round((all_home3_occupanttype_hometype_top1$cumsum/all_home3_occupanttype_hometype_top1$cumsum2)*100)

## calculate profile number by each segment
## input: data of all_home3_occupanttype_hometype_top1, segment name, period
profil_number(all_home3_occupanttype_hometype_top1, "occupanttype",name, month )

## outptu the graphs 
rankseg_output_segment(all_home3_occupanttype_hometype_top1, paste("occupanttype_hometype", name),PathNameseg)


################### RoomsBelow40m2################################


ASSURLAND_HOME_DA_BNP1$roomsbelow40m2=matrix_HOME$roomsbelow40m2[match(ASSURLAND_HOME_DA_BNP1$profilID,matrix_HOME$profil_id)]

ASSURLAND_HOME_DA_roomsbelow40m2=subset(ASSURLAND_HOME_DA_BNP1,select=c(profilID, insurer,period,coverage,price,roomsbelow40m2))

ASSURLAND_HOME_DA_roomsbelow40m2$roomsbelow40m2=ifelse(ASSURLAND_HOME_DA_roomsbelow40m2$roomsbelow40m2<3,"0-2",ifelse(ASSURLAND_HOME_DA_roomsbelow40m2$roomsbelow40m2==3,"3",
                                                                                                                      ifelse(ASSURLAND_HOME_DA_roomsbelow40m2$roomsbelow40m2==4,"4",ifelse(ASSURLAND_HOME_DA_roomsbelow40m2$roomsbelow40m2>4,"5-8",""))))

## renames all the variables
names(ASSURLAND_HOME_DA_roomsbelow40m2)=c("profilID", "insurer","period","coverage","price","segment")

## ## find the top1 profile by segment
all_home3_roomsbelow40m2_top1=top1propor_segment(ASSURLAND_HOME_DA_roomsbelow40m2)

## calculate proportion
all_home3_roomsbelow40m2_top1$proportion=round((all_home3_roomsbelow40m2_top1$cumsum/all_home3_roomsbelow40m2_top1$cumsum2)*100)

## calculate profile number by each segment
## input: data of all_home3_occupanttype_hometype_top1, segment name, period
profil_number(all_home3_roomsbelow40m2_top1, "roomsbelow40m2",name, month )

## outptu the graphs 
rankseg_output_segment(all_home3_roomsbelow40m2_top1, paste("roomsbelow40m2", name),PathNameseg)

############################## region################################

######### find the region and city name for each profile 

ASSURLAND_HOME_DA_BNP1$region=matrix_HOME$directionregionale[match(ASSURLAND_HOME_DA_BNP1$profilID,matrix_HOME$profil_id)]
ASSURLAND_HOME_DA_BNP1$cityname=matrix_HOME$cityname[match(ASSURLAND_HOME_DA_BNP1$profilID,matrix_HOME$profil_id)]

## take Paris out the IDF
ASSURLAND_HOME_DA_BNP1$region=substr(ASSURLAND_HOME_DA_BNP1$region,6,20)
ASSURLAND_HOME_DA_BNP1[ASSURLAND_HOME_DA_BNP1$region=="BP/ DAP",]$region="IDF(woParis)"
ASSURLAND_HOME_DA_BNP1[ASSURLAND_HOME_DA_BNP1$cityname=="PARIS",]$region="PARIS"

table(ASSURLAND_HOME_DA_BNP1$region)

## keep only useful variables and rename them
ASSURLAND_HOME_DA_region=subset(ASSURLAND_HOME_DA_BNP1,select=c(profilID, insurer,period,coverage,price,region))
names(ASSURLAND_HOME_DA_region)=c("profilID", "insurer","period","coverage","price","segment")

## ## find the top1 profile by segment
all_home2_region_top1=top1propor_segment(ASSURLAND_HOME_DA_region)
## calculate proportion
all_home2_region_top1$proportion=round((all_home2_region_top1$cumsum/all_home2_region_top1$cumsum2)*100)

## calculate profile number by each segment
## input: data of all_home2_region_top1, segment name, period
profil_number(all_home2_region_top1, "region",name, month )

## outptu the graphs 
rankseg_output_segment(all_home2_region_top1, paste("region",name),PathNameseg)
