


##########Output path##############################################

outputPath = paste("MRH",as.character(format(Sys.Date(),"%Y%b")))
PathNamerank=paste(outputPath,"ranking",sep="/")
PathNameseg=paste(outputPath,"segment",sep="/")
PathNameevol=paste(outputPath,"evolution",sep="/")
PathNameCEBP = paste(outputPath,"Cumulated Evolution By Profile _ graphs",sep="/")
PathNameDE = paste(outputPath,"Display Evolution _ graphs",sep="/")
PathNameAPE = paste(outputPath,"Average premium graphs",sep="/")

dir.create(outputPath,showWarnings = F)
dir.create(PathNamerank,showWarnings = F)
dir.create(PathNameseg,showWarnings = F)
dir.create(PathNameevol,showWarnings = F)
dir.create(PathNameCEBP,showWarnings = F)
dir.create(PathNameDE,showWarnings = F)
dir.create(PathNameAPE,showWarnings = F)
