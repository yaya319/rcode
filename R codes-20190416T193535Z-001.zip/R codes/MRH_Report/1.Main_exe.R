####################### Online reports update process ############################

## Comments ##
#################data prepation step###################
rm(list=ls(all=TRUE))
gc()

### session--> set working directory--> To sources files locations

wd <- getwd()
setwd("..")
workingDirectory <- getwd()
setwd(workingDirectory)
#Check: should be ~\Report-Online
getwd()


# parametres for download and upload data
db="jupiter"
dbMetis="metis"
dbHost="localhost"
dbPort="5433"
dbUser="axa.cia.crawling"
dbPassword="g2nx0d4nC4"


#Set Libraries and Directories where we will store the results
source("./MRH_Report/Libraries.R")
source("./MRH_Report/Directories.R")
#load functions
source("./MRH_Report/function for reporting_Generic.R")
# set parametres
source("./MRH_Report/parametres_setting.R")


## define crawling period--> this depend on when we crawl the data 
crawled_period="Y16M06"

### preparation the data for DA and BNP: check the connection of juptier firstly 
source("./MRH_Report/Data_process_MRH.R")
## output tables: ASSURLAND_HOME_DA_BNP--> all the data

## check if there new players
newinsurer=unique(ASSURLAND_HOME_DA_BNP$insurer)[!unique(ASSURLAND_HOME_DA_BNP$insurer)%in%All_players]
newinsurer

################################Analyses: top1 ranking + ranking by players + price gap ######################################
###define the period for price gap study
month=c("Y15M11", "Y16M03","Y16M06")

###################Analyses for BNP#####################
## define the scope of competitors
player=BNP_players
## the name for outputs
Name="BNP Natio"

## the input data: select only the scope for BNP
ASSURLAND_HOME_DA_BNP1=ASSURLAND_HOME_DA_BNP[ASSURLAND_HOME_DA_BNP$insurer%in%player,]

## input data--> BNP price with competitors prices
## output graphs: top1 ranking + ranking by players + price gap + mean of price gap 
source("./MRH_Report/analyses_top1_rankingbyplayer_pricgap.R")


###################Analyses for DA#####################
## define the scope of competitors
player=DA_players
## the name for outputs
Name="Direct Assurance"

## the input data: select only the scope for BNP
ASSURLAND_HOME_DA_BNP1=ASSURLAND_HOME_DA_BNP[ASSURLAND_HOME_DA_BNP$insurer%in%player,]

## input data--> BNP price with competitors prices
## output graphs: top1 ranking + ranking by players + price gap + mean of price gap 
source("./MRH_Report/analyses_top1_rankingbyplayer_pricgap.R")


##############price gap a insurer vs another insurer: not for standard analyses of report############ 

month=c("Y15M11", "Y16M03","Y16M06")

# price_gap_ovo(database,period,insurer0, insurer1): price gap=insurer0/insurer1-1
## input the database
##output the price gap graphs;  prce gap mean table; 
## princt the common profiles number for basic coverage and comfortable coverages


## BNP VS MMA
price_gap_ovo(ASSURLAND_HOME_DA_BNP,month,"BNP Natio", "MMA")

## BNP VS MAAF
price_gap_ovo(ASSURLAND_HOME_DA_BNP,month,"BNP Natio", "MAAF Assurances")

## BNP VS AcommeAssure
price_gap_ovo(ASSURLAND_HOME_DA_BNP,month,"BNP Natio", "AcommeAssure")

## BNP VS GMF
price_gap_ovo(ASSURLAND_HOME_DA_BNP,month,"BNP Natio", "GMF")


## DA VS MMA
price_gap_ovo(ASSURLAND_HOME_DA_BNP,month,"Direct Assurance", "MMA")

## DA VS MAAF
price_gap_ovo(ASSURLAND_HOME_DA_BNP,month,"Direct Assurance", "MAAF Assurances")

## DA VS AcommeAssure
price_gap_ovo(ASSURLAND_HOME_DA_BNP,month,"Direct Assurance", "AcommeAssure")

## DA VS GMF
price_gap_ovo(ASSURLAND_HOME_DA_BNP,month,"Direct Assurance", "GMF")
## fewer common profiles number: no need for the analyses 

########################segment anaysis##################################
#-  OccupantType+home variable
#-  RoomsBelow40m2 variable
# -region variable 


##segment anaysis for direct assurance
## input--> name, player scope, data
## output: three segments analyses

name="Direct Assurance"
player=DA_players
month=unique(ASSURLAND_HOME_DA_BNP$period)

ASSURLAND_HOME_DA_BNP1=ASSURLAND_HOME_DA_BNP[ASSURLAND_HOME_DA_BNP$insurer%in%player, ]

source("./MRH_Report/segment_analyses.R")

### segment anaysis for BNP Natio
## input--> name, player scope, data
## output: three segments analyses
name="BNP Natio"
player=BNP_players
month=unique(ASSURLAND_HOME_DA_BNP$period)
ASSURLAND_HOME_DA_BNP1=ASSURLAND_HOME_DA_BNP[ASSURLAND_HOME_DA_BNP$insurer%in%player, ]
source("./MRH_Report/segment_analyses.R")


## cumulated evolution
## input the whole database
## output the cumulated evolution graph, average premium graph, display rate 

source("./MRH_Report/cumulated_evol.R")

## output the graphs in PPT

source("./MRH_Report/output_ppt.R")
 
