### update the prices of competitors with crawling data and prices of BNP and DA with calculation data by DA#################

#### crawling price 2015====

### loads the PostgreSQL driver
drv <- dbDriver("PostgreSQL")
#### Open a connection
con <- dbConnect(drv, dbname=db, host=dbHost, port=dbPort , user=dbUser, password=dbPassword)


matrix_HOME= dbGetQuery(con,  "select*
                        from business.\"legacy_matrix_HOME_FR\";")

## set the name of compagne ID
compagne=paste("'%", crawled_period, "_RECURRENT%'",sep="")


ASSURLAND_HOME =  dbGetQuery(con,  paste("select *
                                from crawling.\"ASSURLAND_HOME_prices\" where \"campaignID\" like ", compagne, " ;" ,sep=" "))

## Closes the connection
lapply(dbListConnections(drv), FUN = dbDisconnect)

## Frees all the resources on the driver
dbUnloadDriver(drv)

### crawling data====
## name yearmonth variable
ASSURLAND_HOME$yearmonth <- paste( "Y",substr(ASSURLAND_HOME$year,3,4), "M",formatC(ASSURLAND_HOME$month,width=2, flag="0") , sep = "")
table(ASSURLAND_HOME$yearmonth)

## select only the useful variables
ASSURLAND_HOME=subset(ASSURLAND_HOME, select=c(profilID, insurer, coverage, prix, status,yearmonth))
colnames(ASSURLAND_HOME)[4]="price"

## check the price
summary(ASSURLAND_HOME$price)

## remove the invalide price
ASSURLAND_HOME=ASSURLAND_HOME[!ASSURLAND_HOME$price==0,]
summary(ASSURLAND_HOME$price)

# variable formule origine for each profil
ASSURLAND_HOME$formule_origine=matrix_HOME$formule_origine[match(ASSURLAND_HOME$profilID,matrix_HOME$profil_id)]
## mapping for the coverages
ASSURLAND_HOME$coverage=ifelse(ASSURLAND_HOME$formule_origine=="2", "La formule Essentielle", "La formule Confort")
ASSURLAND_HOME$insurer=as.character(ASSURLAND_HOME$insurer)

## calculate display rate for both coverages 
tauxess=length(unique(ASSURLAND_HOME[ASSURLAND_HOME$coverage=="La formule Essentielle" ,]$profilID))/length(unique(ASSURLAND_HOME$profilID))
tauxcon= length(unique(ASSURLAND_HOME[ASSURLAND_HOME$coverage=="La formule Confort" ,]$profilID))/length(unique(ASSURLAND_HOME$profilID))

tauxess #42%
tauxcon #58%
ASSURLAND_HOME=subset(ASSURLAND_HOME, select=c(profilID,insurer,coverage,price,yearmonth))

## BNP and DA price: calculated by DA, check if there are tarrif changes for DA side, if yes, we need to changes the tarrif tables====


#############################201606 tarrif
### new tarrif for BNP
New_price_06=read.csv2("./mapping_table/MRP/201606/MRH_Matrix_201603newbnp.csv",header=T,sep=";",dec=".")
New_price_06$PTTC_TOTAL_BNP_ECO=as.numeric(gsub(",", ".", gsub("\\.", "", New_price_06$PTTC_TOTAL_BNP_ECO)))
New_price_06$PTTC_TOTAL_BNP_CONF=as.numeric(gsub(",", ".", gsub("\\.", "", New_price_06$PTTC_TOTAL_BNP_CONF)))

##BNP price
Bnpprice_16f06=price_extrat(New_price_06, "PTTC_TOTAL_BNP_ECO", "PTTC_TOTAL_BNP_CONF","BNP Natio")
summary(Bnpprice_16f06$price)

### give the period for the BNP
crawl_period_bnp=crawled_period

## select only the commun profiles between bnp and crawled profiles

for(i in 1:length(crawl_period_bnp)){
  
  Bnppric_16e061=Bnpprice_16f06
  Bnppric_16e061$yearmonth =crawl_period_bnp
  
  
  listess=unique(ASSURLAND_HOME[ASSURLAND_HOME$coverage=="La formule Essentielle"& ASSURLAND_HOME$yearmonth ==crawl_period_bnp[i],]$profilID)
  listconf=unique(ASSURLAND_HOME[ASSURLAND_HOME$coverage=="La formule Confort"& ASSURLAND_HOME$yearmonth ==crawl_period_bnp[i],]$profilID)
  length(listess)
  length(listconf)
  ## choose commun profils 
  Bnpprice_161_ess06=Bnppric_16e061[Bnppric_16e061$coverage=="La formule Essentielle", ]
  Bnpprice_161_ess06=Bnpprice_161_ess06[Bnpprice_161_ess06$profilID%in%listess,]
  ## choose commun profils 
  Bnpprice_161_conf06=Bnppric_16e061[Bnppric_16e061$coverage=="La formule Confort", ]
  Bnpprice_161_conf06=Bnpprice_161_conf06[Bnpprice_161_conf06$profilID%in%listconf,]
  
  Bnpprice_16206=rbind(Bnpprice_161_ess06,Bnpprice_161_conf06)
  
  if (i==1) (Bnpprice_16f06final=as.data.frame(Bnpprice_16206)) else Bnpprice_16f06final=rbind(Bnpprice_16f06final, Bnpprice_16206)
  Bnpprice_16f06final=na.omit(Bnpprice_16f06final)
}
### select only useful variables
Bnpprice_16f06final=subset(Bnpprice_16f06final, select=c(profilID,insurer,coverage, price , yearmonth))


## DA price: the same as in 201603
New_price=read.csv2("./mapping_table/MRP/201603/MRH_Matrix_201603.csv",header=T,sep=";",dec=".")
### take DA price 
DAprice_16=price_extrat(New_price, "pttc_da_Eco", "pttc_da_confort_sans_del","Direct Assurance")

### give the period for the DA
crawl_period_DA=crawled_period

## select only the commun profiles between DA and crawled profiles

for(i in 1:length(crawl_period_DA)){
  
  DAprice_161=DAprice_16
  DAprice_161$yearmonth =crawl_period_DA[i]
  
  listess=unique(ASSURLAND_HOME[ASSURLAND_HOME$coverage=="La formule Essentielle"& ASSURLAND_HOME$yearmonth ==crawl_period_DA[i],]$profilID)
  listconf=unique(ASSURLAND_HOME[ASSURLAND_HOME$coverage=="La formule Confort"& ASSURLAND_HOME$yearmonth ==crawl_period_DA[i],]$profilID)
  length(listess)
  length(listconf)
  ## choose commun profils 
  DAprice_161_ess=DAprice_161[DAprice_161$coverage=="La formule Essentielle", ]
  DAprice_161_ess=DAprice_161_ess[DAprice_161_ess$profilID%in%listess,]
  ## choose commun profils 
  DAprice_161_conf=DAprice_161[DAprice_161$coverage=="La formule Confort", ]
  DAprice_161_conf=DAprice_161_conf[DAprice_161_conf$profilID%in%listconf,]
  DAprice_162=rbind(DAprice_161_ess,DAprice_161_conf)
  
  rm(DAprice_161)
  rm(DAprice_161_ess)
  rm(DAprice_161_conf)
  
  if (i==1) (DAprice_16f=as.data.frame(DAprice_162)) else DAprice_16f=rbind(DAprice_16f, DAprice_162)
  
}


DAprice_16f=subset(DAprice_16f, select=c(profilID,insurer,coverage, price , yearmonth))

## group competitors price with DA and BNP 
ASSURLAND_HOME_BNP_DA=rbind(ASSURLAND_HOME, Bnpprice_16f06final,  DAprice_16f )

## load the history database
load("./Output_MRH/ASSURLAND_HOME_DA_BNP.Rdata" )

## only take the new period 
ASSURLAND_HOME=ASSURLAND_HOME[!ASSURLAND_HOME$period%in%unique(ASSURLAND_HOME_DA_BNP$period),]

## group old and new data
ASSURLAND_HOME_DA_BNP = rbind(ASSURLAND_HOME_DA_BNP,ASSURLAND_HOME)
## avoid the duplicated data
ASSURLAND_HOME_DA_BNP=unique(ASSURLAND_HOME_DA_BNP)

## save all the data for next analyses
save(ASSURLAND_HOME_DA_BNP, file = "./Output_MRH/ASSURLAND_HOME_DA_BNP.RData")

