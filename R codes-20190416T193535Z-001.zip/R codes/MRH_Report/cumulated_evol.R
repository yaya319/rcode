### display rate
### average premium
### cumulated evolution

#################################################calcul stat by weeks#########################################################

### DA + BNP

frdata_cumul=unique(ASSURLAND_HOME_DA_BNP)

res=data.frame(frdata_cumul$period,frdata_cumul$price,frdata_cumul$insurer,frdata_cumul$profilID,frdata_cumul$coverage)
names(res)=c("period","price","insurer","profilID","coverage")


res=res[res$coverage%in%covfr,]
res=res[order(res$period),]

wNames <- unique(as.character(res$period))
playersNames <- levels(as.factor(res$insurer))

# Summary Tab
summaryTab <- data.frame("insurer"=NaN,"coverage"=NaN,"period"=NaN,
                         "PlayerType"=NaN,"AvgEvolByProfile"=NaN,"ImpactedProfile"=NaN,
                         "AvgPremium"=NaN,
                         "AvgPremium_var"=NaN,
                         "Display_prop" = NaN,
                         "Display_var" = NaN,
                         "NbProfiles"=NaN) 

#####calcul with the function onePeriodStats for every period

for(wi in 1:length(wNames)-1){
  
  w1 <- wNames[wi]
  w2 <- wNames[wi+1]
  summaryTab <- rbind(summaryTab,onePeriodStats(res,w1,w2))
  
  # return (summaryTab)
}


summaryTab <- na.omit(summaryTab)
summaryTab$insurer <- as.factor(summaryTab$insurer)
summaryTab$coverage <- as.factor(summaryTab$coverage)
summaryTab$period <- as.factor(summaryTab$period)
summaryTab$Playertype <- as.factor(summaryTab$PlayerType)

summaryTab=unique(summaryTab)

# save the data

save(summaryTab,file=paste0("./output_MRH/summaryTab.RData"))


summaryTab=unique(summaryTab)

## output display rate and average premium graph

display_graphs(summaryTab,formulaNames,TypesC,Types,PathNameDE)

average_graphs(summaryTab,formulaNames,TypesC,Types,PathNameAPE)

###########################################################
######### cumul evolution graphs for all periods###########
###########################################################

##calculate log variation between two periods in using  "onePeriodlog" function

summaryCumulTab<- data.frame("profilID"=NaN,"insurer"=NaN,"coverage"=NaN,"period"=NaN,"LNEvolByProfile"=NaN)

cl<-makeCluster(4)
registerDoParallel(cl)

#1. compute log period2/period1
# summaryCumulTab=foreach(wi = 1:length(wNames)-1, .combine=rbind) %dopar% {
for(wi in 1:length(wNames)-1){
  
  wi
  w1 <- wNames[wi]
  w2 <- wNames[wi+1]
  
  summaryCumulTab<- rbind(summaryCumulTab,onePeriodlog(res,w1,w2))
  
}


# summaryCumulTabtest=na.omit(summaryCumulTab)
# # # ## find big variation and output thoses profiles to check 
summaryCumulTabtest$LNEvolByProfile=ifelse(summaryCumulTabtest$LNEvolByProfile>threshold1,"check",ifelse(summaryCumulTabtest$LNEvolByProfile<threshold2,"check",summaryCumulTabtest$LNEvolByProfile))

checkprofiles_bigvar=summaryCumulTabtest[summaryCumulTabtest$LNEvolByProfile=="check",]
checkprofiles_bigvar=unique(checkprofiles_bigvar)
# 
# # ## take only no big variation profiles 
summaryCumulTab=summaryCumulTabtest[!summaryCumulTabtest$LNEvolByProfile=="check",]

summaryCumulTab$LNEvolByProfile=as.numeric(summaryCumulTab$LNEvolByProfile)
summaryCumulTab$LNEvolByProfile=round(100*summaryCumulTab$LNEvolByProfile)
summaryCumulTab=na.omit(summaryCumulTab)
summaryCumulTab$insurer <- as.factor(summaryCumulTab$insurer)
summaryCumulTab$coverage <- as.factor(summaryCumulTab$coverage)
summaryCumulTab$period <- as.factor(summaryCumulTab$period)

save(summaryCumulTab,file=paste("./output_MRH/summaryCumulTab.RData"))

### 2. cumule evol by profil

# #Remove years before 2015 
summaryCumulTab1=summaryCumulTab[grepl("Y15|Y16",summaryCumulTab$period),]
summaryCumulTab1$period <- factor(summaryCumulTab1$period)
#Compute Key and format dataframe as data table
summaryCumulTab1$ind=paste(summaryCumulTab1$insurer,summaryCumulTab1$coverage,summaryCumulTab1$profilID)
summaryCumulTab1 <- data.table(summaryCumulTab1)
#Reorder
summaryCumulTab1=summaryCumulTab1[order(summaryCumulTab1$ind,summaryCumulTab1$period),]
#Compute cumul evoution 
newcumul=summaryCumulTab1[  ,list(cumullog=cumevollogFunc(LNEvolByProfile)),by=list(ind,insurer,coverage,profilID)]
#Compute exponential
newcumul$Exp=round(exp(newcumul$cumullog/100)-1,4)

#Join new results 
JoinResult=cbind(summaryCumulTab1, newcumul)

meanna=function(x) {
  return(mean(x,na.rm=T))
}

#Remove duplicated columns
JoinResult=subset(JoinResult,select=c(profilID,insurer,coverage,period,LNEvolByProfile,cumullog,Exp))
JoinResult=unique(JoinResult)
logevolfinal <- data.table(JoinResult)
logevolfinal <- logevolfinal[,list(mean=meanna(Exp)), by = c("coverage","period","insurer")]
logevolfinal=unique(logevolfinal)

logevolfinal2=logevolfinal

logevolfinal2$mean=round(logevolfinal2$mean*100,2)
logevolfinal2$Playertype =""
logevolfinal2[logevolfinal2$insurer%in%DIRECTPlayers,]$Playertype="DIRECT"
 
save(logevolfinal2,file=paste0("./output_MRH/logevolfinal2.RData"))

## output cumulated evolution graph
cumullog_graphs(logevolfinal2,formulaNames,TypesC,Types,PathNameCEBP)



