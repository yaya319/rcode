
## top 1 ranking
## find top 1 rank with function top1propor
ASSURLAND_HOME_DA_top1=top1propor(ASSURLAND_HOME_DA_BNP1)
## calculate proportion
ASSURLAND_HOME_DA_top1$proportion=ASSURLAND_HOME_DA_top1$cumsum/ASSURLAND_HOME_DA_top1$cumsum2
ASSURLAND_HOME_DA_top1$proportion=round(ASSURLAND_HOME_DA_top1$proportion*100)

## output graphs
top1all(ASSURLAND_HOME_DA_top1, covfr, Name)

###ranking over time

## select only usefuf variables
ASSURLAND_HOME_r=subset(ASSURLAND_HOME_DA_BNP1,select=c(profilID,insurer,coverage,price,yearmonth))
names(ASSURLAND_HOME_r)=c("profilID","insurer","coverage","price","yearmonth")
## remove duplicated data
ASSURLAND_HOME_r=unique(ASSURLAND_HOME_r)
## output graphs
genrankovermonths(ASSURLAND_HOME_r,Name,Name,covfr)


###############price gap
# calculate price gap
pricegap_global=price_gap(ASSURLAND_HOME_DA_BNP1,month,Name)

### output the graphs
datainput=pricegap_global
name=Name

print(ggplot() +
        geom_density(aes(x=datainput$delta[datainput$coverage==covfr[1] & datainput$yearmonth==month[1]],y=(..count..)/sum(..count..)),colour="royalblue1",alpha = 0.5, size=1) +
        geom_density(aes(x=datainput$delta[datainput$coverage==covfr[2]& datainput$yearmonth==month[1]],y=(..count..)/sum(..count..)),colour="tomato", alpha = 0.5,size=1) +
        geom_density(aes(x=datainput$delta[datainput$coverage==covfr[1] & datainput$yearmonth==month[2]],y=(..count..)/sum(..count..)),colour="royalblue1",alpha = 0.8, size=1.5) +
        geom_density(aes(x=datainput$delta[datainput$coverage==covfr[2]& datainput$yearmonth==month[2]],y=(..count..)/sum(..count..)),colour="tomato", alpha = 0.8,size=1.5) +
        geom_density(aes(x=datainput$delta[datainput$coverage==covfr[1] & datainput$yearmonth==month[3]],y=(..count..)/sum(..count..)),colour="royalblue1",alpha = 1, size=2) +
        geom_density(aes(x=datainput$delta[datainput$coverage==covfr[2]& datainput$yearmonth==month[3]],y=(..count..)/sum(..count..)),colour="tomato", alpha = 1,size=2) +
        
        geom_vline(xintercept=0) +
        
        annotate("text", label = paste(covfr[1],month[1], sep=" "),colour= "royalblue1", x = 0.8, y = 0.0028, size=5,alpha = 0.5) +
        annotate("text", label = paste(covfr[2],month[1],sep=" "),colour= "tomato", x = 0.8,y = 0.0024, size=5,,alpha = 0.5) +
        annotate("text", label = paste(covfr[1],month[2], sep=" "),colour= "royalblue1", x = 0.8, y = 0.0020, size=5,alpha = 1) +
        annotate("text", label = paste(covfr[2],month[2],sep=" "),colour= "tomato", x = 0.8, y = 0.0016, size=5,,alpha = 1) +
        annotate("text", label = paste(covfr[1],month[3], sep=" "),colour= "royalblue1", x = 0.8, y = 0.0012, size=5,alpha = 1) +
        annotate("text", label = paste(covfr[2],month[3],sep=" "),colour= "tomato", x = 0.8, y = 0.0008, size=5,,alpha = 1) +
        
        wt +
        ggtitle(paste(paste(name, " price gap to its competitors",sep=" "),sep="\n\n\n")) +
        xlab(label = "")+ 
        ylab(label="% MRP")  + scale_x_continuous(labels = percent, breaks=seq(-10,10,0.2)))

ggsave(paste(PathNameevol,file=paste(name, "CI-DeltaMin-Direct_all.png",sep=" "),sep="/"),width=16,height=9,dpi=100)

### out put the table of price gap mean  

delta1_left=datainput
delta1_left=na.omit(delta1_left)
sum_last_left1=data.frame("period"=unique(datainput$yearmonth)[1],"coverage"=unique(datainput$coverage), "mean"=0)
sum_last_left2=data.frame("period"=unique(datainput$yearmonth)[2],"coverage"=unique(datainput$coverage), "mean"=0)
sum_last_left3=data.frame("period"=unique(datainput$yearmonth)[3],"coverage"=unique(datainput$coverage), "mean"=0)

sum_last_left=rbind(sum_last_left1,sum_last_left2,sum_last_left3)

sum_last_left[sum_last_left$coverage=="Basic Coverage"&sum_last_left$period==unique(datainput$yearmonth)[1],]$mean=round(mean(delta1_left[delta1_left$coverage=="Basic Coverage"&delta1_left$yearmonth==unique(delta1_left$yearmonth)[1],]$delta)*100)
sum_last_left[sum_last_left$coverage=="Basic Coverage"&sum_last_left$period==unique(datainput$yearmonth)[2] ,]$mean=round(mean(delta1_left[delta1_left$coverage=="Basic Coverage"& delta1_left$yearmonth==unique(delta1_left$yearmonth)[2],]$delta)*100)
sum_last_left[sum_last_left$coverage=="Basic Coverage"&sum_last_left$period==unique(datainput$yearmonth)[3] ,]$mean=round(mean(delta1_left[delta1_left$coverage=="Basic Coverage"& delta1_left$yearmonth==unique(delta1_left$yearmonth)[3],]$delta)*100)

sum_last_left[sum_last_left$coverage=="Comfortable Coverage" &sum_last_left$period==datainput$yearmonth[1] ,]$mean=round(mean(delta1_left[delta1_left$coverage=="Comfortable Coverage" &delta1_left$yearmonth==unique(delta1_left$yearmonth)[1],]$delta)*100)
sum_last_left[sum_last_left$coverage=="Comfortable Coverage" &sum_last_left$period==unique(datainput$yearmonth)[2] ,]$mean=round(mean(delta1_left[delta1_left$coverage=="Comfortable Coverage" & delta1_left$yearmonth==unique(delta1_left$yearmonth)[2],]$delta)*100)
sum_last_left[sum_last_left$coverage=="Comfortable Coverage" &sum_last_left$period==unique(datainput$yearmonth)[3] ,]$mean=round(mean(delta1_left[delta1_left$coverage=="Comfortable Coverage" & delta1_left$yearmonth==unique(delta1_left$yearmonth)[3],]$delta)*100)

png_new(sum_last_left,PathNameevol,paste("mean", name),600,600)





