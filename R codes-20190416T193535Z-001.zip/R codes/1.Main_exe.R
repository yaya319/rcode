####################### Online reports update process ############################

## Comments ##
#################data prepation step###################
rm(list=ls(all=TRUE))
gc()

### session--> set working directory--> To sources files locations

wd <- getwd()
setwd("..")
workingDirectory <- getwd()
setwd(workingDirectory)
#Check: should be ~\Report-Online
getwd()


# parametres for download and upload data
db="jupiter"
dbMetis="metis"
dbHost="localhost"
dbPort="5433"
dbUser="axa.cia.crawling"
dbPassword="g2nx0d4nC4"


#Set Libraries and Directories where we will store the results
source("./MRH_Report/Libraries.R")
source("./MRH_Report/Directories.R")
#load functions
source("./MRH_Report/function for reporting_Generic.R")
# set parametres
source("./MRH_Report/parametres_setting.R")


## define crawling period--> this depend on when we crawl the data 
# crawled_period="Y16W35"
# definit_period="Y16M09"

# crawled_period="Y16M06"
# definit_period="Y16M06"
### preparation the data for DA and BNP: check the connection of juptier firstly 
## output tables: ASSURLAND_HOME_DA_BNP--> all the data
# 
# load("./Output_MRH/ASSURLAND_HOME_DA_BNP.Rdata" )
# ASSURLAND_HOME_DA_BNP=rbind(ASSURLAND_HOME_DA_BNP,  Y16M10)
## check if there new players
source("./MRH_Report/Data_process_MRH.R")
newinsurer=unique(all$insurer)[!unique(all$insurer)%in%All_players]
newinsurer

## mapping for the coverages
all$coverage_def=ifelse(all$formule_origine=="2" & all$coverage== "Basic Coverage", "Y",
                        ifelse(all$formule_origine=="3" &all$coverage== "Comfortable Coverage",  "Y",
                               ifelse(all$formule_origine=="4" &all$coverage== "PNO","Y", "else")))
table(all$coverage_def)

## select the scope
old_scope=c("Y")
# new_scope=c("Y", "else")

all=all[all$coverage_def%in%old_scope, ]
# 
# all=all[!all$insurer%in%c("Pacifica", "Macif"), ]

all=subset(all, select=-c(coverage_def, formule_origine))

print(length(unique(all[all$coverage=="Basic Coverage",]$profilID)))
print(length(unique(all[all$coverage=="Comfortable Coverage",]$profilID)))
print(unique(all$period))

month=c("Y16M09" ,  "Y16M09_Mario" )
## use this database 
ASSURLAND_HOME_DA_BNP=all[all$period%in%month, ]


### price changes #######

covfr=c("Basic Coverage" ,"Comfortable Coverage", "PNO")
source("./MRH_Report/price_distribution.R")


covfr=c("Basic Coverage" ,"Comfortable Coverage", "PNO")
coveragenames=c("Basic Coverage" ,"Comfortable Coverage", "PNO"  )
################################Analyses: top1 ranking + ranking by players + price gap ######################################
###################Analyses for DA#####################
month=c("Y16M09" ,  "Y16M09_Mario" )
# month=c("Y16M09" ,  "Y16M09_Mariov9" , "Y16M09_Mariov10")

## define the scope of competitors
player=DA_players
## the name for outputs
Name="Direct Assurance"

## the input data: select only the scope for BNP
ASSURLAND_HOME_DA_BNP1=ASSURLAND_HOME_DA_BNP[ASSURLAND_HOME_DA_BNP$insurer%in%player,]

ASSURLAND_HOME_DA_BNP1=ASSURLAND_HOME_DA_BNP1[ASSURLAND_HOME_DA_BNP1$period%in%month,]

ASSURLAND_HOME_DA_BNP1=ASSURLAND_HOME_DA_BNP1[order(ASSURLAND_HOME_DA_BNP1$period),]

# ASSURLAND_HOME_DA_BNP1=ASSURLAND_HOME_DA_BNP1[!ASSURLAND_HOME_DA_BNP1$insurer=="Pacifica",]

## input data--> BNP price with competitors prices
## output graphs: top1 ranking + ranking by players + price gap + mean of price gap 
source("./MRH_Report/analyses_top1_rankingbyplayer_pricgap.R")


##############price gap a insurer vs another insurer: not for standard analyses of report############ 

price_gap_ovo_v2(ASSURLAND_HOME_DA_BNP,month,"Direct Assurance", "Pacifica")

## DA VS MAAF
price_gap_ovo_v2(ASSURLAND_HOME_DA_BNP,month,"Direct Assurance", "MAAF Assurances")

## DA VS AcommeAssure
price_gap_ovo_v2(ASSURLAND_HOME_DA_BNP,month,"Direct Assurance", "AcommeAssure")


## DA VS "Carrefour Assurances"
price_gap_ovo_v2(ASSURLAND_HOME_DA_BNP,month,"Direct Assurance", "Carrefour Assurances")

## DA VS AcommeAssure
price_gap_ovo_v2(ASSURLAND_HOME_DA_BNP,month,"Direct Assurance", "Pacifica")

## DA VS AcommeAssure
price_gap_ovo_v2(ASSURLAND_HOME_DA_BNP,month,"Direct Assurance", "Macif")

## fewer common profiles number: no need for the analyses 

########################segment anaysis##################################
#-  OccupantType+home variable
#-  RoomsBelow40m2 variable
# -region variable 


##segment anaysis for direct assurance
## input--> name, player scope, data
## output: three segments analyses

name="Direct Assurance"
player=DA_players
month=unique(ASSURLAND_HOME_DA_BNP$period)

ASSURLAND_HOME_DA_BNP1=ASSURLAND_HOME_DA_BNP[ASSURLAND_HOME_DA_BNP$insurer%in%player, ]

source("./MRH_Report/segment_analyses.R")


## price gap by region


  ASSURLAND_HOME_DA_BNP1_region=ASSURLAND_HOME_DA_BNP1[ASSURLAND_HOME_DA_BNP1$region%in%c("IDF(woParis)","PARIS"),]
  month=c("Y16M09")
  Name="Direct Assurance"
  originaldata=ASSURLAND_HOME_DA_BNP1_region
  source("./MRH_Report/price_gap_global.R")
  

ASSURLAND_HOME_DA_BNP1_region=ASSURLAND_HOME_DA_BNP1[ASSURLAND_HOME_DA_BNP1$region%in%c("PARIS"),]
month=c("Y16M09")
Name="Direct Assurance"
originaldata=ASSURLAND_HOME_DA_BNP1_region


## cumulated evolution
## input the whole database
## output the cumulated evolution graph, average premium graph, display rate 

source("./MRH_Report/cumulated_evol.R")

## output the graphs in PPT

source("./MRH_Report/output_ppt.R")
 
