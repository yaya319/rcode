
########parameters setting########

### colors
my.cols <- c("#c7eae5","#1f78b4","#b2df8a","#33a02c","#fb9a99","#e31a1c","#fdbf6f","#ff7f00","#c51b7d","#6a3d9a","#ffff99","#b15928",
             "#8dd3c7","#004529","#bebada","#fb8072","#80b1d3","#fdb462","#b3de69","#756bb1")

colorpalette<-c("MAAF Assurances"=my.cols[2],"MMA"=my.cols[3],"Groupe ASSU 2000"=my.cols[4],
                "AcommeAssure"=my.cols[5],"Direct Assurance"=my.cols[6],"Carrefour Assurances"=my.cols[11],"BNP Natio"=my.cols[8],
                "GMF"=my.cols[10], "AXA_FR"="#66c2a4", "Macif"="#084594"  ,"Pacifica"="#ae017e" )
show_col(colorpalette)

## formulas definitions
covfr=c("Basic Coverage" ,"Comfortable Coverage"  )
coveragenames=c("Basic Coverage" ,"Comfortable Coverage"  )

# define coverage
formulaNames <- covfr
formulaTypes <- coveragenames
formulaMapping <- cbind(formulaNames,formulaNames)


### for ranking scopes
Types_analyses <- c("BNP_players","DA_players", "AXA_palyers") 

BNP_players=c("MMA"  ,   "MAAF Assurances" , "Groupe ASSU 2000" , "AcommeAssure" ,"Carrefour Assurances", "GMF", "BNP Natio")
DA_players=c("Direct Assurance",   "MMA",  "MAAF Assurances", "Groupe ASSU 2000" ,"AcommeAssure", "Carrefour Assurances","GMF","Macif" ,"Pacifica" )
AXA_palyers=c("AXA_FR",   "MMA",  "MAAF Assurances", "Groupe ASSU 2000" ,"AcommeAssure", "Carrefour Assurances","GMF") 


#### for cumulated evolution analyses
# define type
Types <- c("DIRECT") 
TypesC <- data.frame(types = Types,typesComplete = c("Direct : Direct Players")) 

# define players types
All_players=c("Direct Assurance",   "MMA",  "MAAF Assurances", "Groupe ASSU 2000" ,"AcommeAssure", "Carrefour Assurances","GMF","BNP Natio", "Macif" ,"Pacifica" )
DIRECTPlayers <-All_players
