## decision tree for MRH profiles 

## take only matrix in 201507: this was loaded in the data prepartion step

load("./Output_MRH/matrix_HOME.Rdata" )

player_delta_cov=player_delta[player_delta$coverage==covfr,]

matrix_HOME=matrix_HOME[grepl("MRH201507",matrix_HOME$profil_id),]

matrix_HOME_delta=merge(matrix_HOME,player_delta_cov, by.x=c("profil_id"), by.y=c("profilID"))

## adjuste for regions
matrix_HOME_delta=data.table(matrix_HOME_delta)
matrix_HOME_delta$region=matrix_HOME_delta$directionregionale

## take Paris out the IDF
matrix_HOME_delta$region=substr(matrix_HOME_delta$region,6,20)
matrix_HOME_delta[matrix_HOME_delta$region=="BP/ DAP",]$region="IDF(woParis)"
matrix_HOME_delta[matrix_HOME_delta$cityname=="PARIS",]$region="PARIS"

## home type
matrix_HOME_delta$hometype=ifelse(matrix_HOME_delta$hometype==1,"Flat",ifelse(matrix_HOME_delta$hometype==2,"House", ""))
table(matrix_HOME_delta$hometype)

table(matrix_HOME_delta$region)

matrix_HOME_delta$occupanttype=ifelse(matrix_HOME_delta$occupanttype==1,"Owner",ifelse(matrix_HOME_delta$occupanttype==2,"Tenant", 
                                                                                                 ifelse(matrix_HOME_delta$occupanttype==3,"Tenant", ifelse(matrix_HOME_delta$occupanttype==4,"InoccupantOwner",""))))
table(matrix_HOME_delta$occupanttype)


matrix_HOME_delta=subset(matrix_HOME_delta, select=c(current_residence, residencetype, occupanttype,
                                                     hometype, veranda,roomsbeyond40m2,roomsbelow40m2, totalsurface, 
                                                     outbuildingsurface, fireplacetype, buildingperiod, unoccupancy, floor, 
                                                     profession,region, delta ))
lapply(matrix_HOME_delta, class)

matrix_HOME_delta$current_residence=as.factor(matrix_HOME_delta$current_residence)
matrix_HOME_delta$residencetype=as.factor(matrix_HOME_delta$residencetype)
matrix_HOME_delta$occupanttype=as.factor(matrix_HOME_delta$occupanttype)
matrix_HOME_delta$hometype=as.factor(matrix_HOME_delta$hometype)
matrix_HOME_delta$veranda=as.factor(matrix_HOME_delta$veranda)
matrix_HOME_delta$roomsbeyond40m2=as.numeric(matrix_HOME_delta$roomsbeyond40m2)
matrix_HOME_delta$roomsbelow40m2=as.numeric(as.character(matrix_HOME_delta$roomsbelow40m2))
matrix_HOME_delta$totalsurface=as.numeric(as.character(matrix_HOME_delta$totalsurface) )                                           
 matrix_HOME_delta$outbuildingsurface=as.numeric(as.character(matrix_HOME_delta$outbuildingsurface))  

matrix_HOME_delta$fireplacetype=as.factor(matrix_HOME_delta$fireplacetype)
matrix_HOME_delta$buildingperiod=as.factor(matrix_HOME_delta$buildingperiod)

matrix_HOME_delta$unoccupancy=as.factor(matrix_HOME_delta$unoccupancy)
matrix_HOME_delta$floor=as.factor(matrix_HOME_delta$floor)
matrix_HOME_delta$profession=as.factor(matrix_HOME_delta$profession)
matrix_HOME_delta$region=as.factor(matrix_HOME_delta$region)
matrix_HOME_delta$outbuildingsurface2=ifelse(matrix_HOME_delta$outbuildingsurface==0,"N","Y") 
matrix_HOME_delta$outbuildingsurface2=as.factor(matrix_HOME_delta$outbuildingsurface2)

if( factor==T){
  matrix_HOME_delta$reponse=ifelse(matrix_HOME_delta$delta>0,0,1)
  matrix_HOME_delta$reponse=as.factor(matrix_HOME_delta$reponse)
}else{
matrix_HOME_delta$reponse=as.numeric(matrix_HOME_delta$delta)
}

## remove useless variables
matrix_HOME_delta=subset(matrix_HOME_delta, select=-c(delta,outbuildingsurface ))
## display the MRP variables class
lapply(matrix_HOME_delta, class)

library(party)
## the decision tree model and print the tree 
Decision_Tree(matrix_HOME_delta, paste(target_player, "Decision_Tree",sep=" "))

