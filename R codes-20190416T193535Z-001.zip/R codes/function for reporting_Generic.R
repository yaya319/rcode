
######### function for reporting###################### 


### get weeks preceding a date. #########
#It allow the exclusion of the most recent in the report 
 
getWeekActu <-function(date,prev)
{
  wk = week(as.Date(date)-7*prev)
  y1 = as.numeric(year(as.Date(date)-7*prev))
  y2 = as.numeric(year(as.Date(date)))
  diff = y2-y1
  if(wk == 53)
  {
    return(paste("Y",as.numeric(str_sub(year(as.Date(date)),3,4))+1-diff,"W01",sep=""))
  }
  else if(wk < 10){
    return(paste("Y",as.numeric(str_sub(year(as.Date(date)),3,4))-diff,"W0",wk,sep=""))
  }else{
    return(paste("Y",as.numeric(str_sub(year(as.Date(date)),3,4))-diff,"W",wk,sep=""))
  }
}


################ previous month#####################
# Gives the previous month in the format Y--M--

pm <- function(dt)
{
  yy = as.numeric(str_sub(dt,2,3))
  mm = as.numeric(str_sub(dt,5,6))
  mm = mm - 1
  if(mm == 0){
    mm = 12
    yy = yy - 1
  }
  if(mm < 10)
  {
    c=paste("Y",yy,"M0",mm,sep="")
  }else{
    c=paste("Y",yy,"M",mm,sep="")
  }
  return(c)
}



#########function for ranking
## by month

# Parameters: data = prankd, AnalysedCompetitor = agdentity, Title of analysis = agdentitysn, Xaxis = Period (could be other variable, such as age)



genrankovermonths = function (prankd,agdentity,agdentitysn,coventity) {
  
  dtrankd=data.table(prankd)
  dtrankd[,rank:=rank(price,ties.method="first"),by=c("profilID","coverage","yearmonth")]
  prankd=data.frame(dtrankd)
  
  for (k in 1:length(coventity)) {
    agrankall=NULL
    for(m in unique(prankd$yearmonth)) {
      prankdc=as.data.frame(table((cut((prankd$rank[grepl(agdentity,prankd$insurer) & prankd$yearmonth==m & prankd$coverage==coventity[k]]),labels=F,breaks=c(0,1,2,3,4,5))),exclude=NULL)/length(prankd$rank[grepl(agdentity,prankd$insurer) & prankd$yearmonth==m & prankd$coverage==coventity[k]]))
      
      names(prankdc)[1]="rankd"
      names(prankdc)[2]="percd"
      prankdc$yearmonth=m
      
      
      
      grankall=as.data.frame(x=c(1,2,3,4,5,NA))
      names(grankall)[1]="ranks"
      grankall$rankstr=c("1st","2nd","3rd","4th","5th","6th +")
      grankall=merge(grankall,prankdc,by.x="ranks",by.y="rankd",all.x=T)
      
      
      grankall$coord=seq(10,60,by=10)
      grankall$yearmonth=m
      grankall$percd[is.na(grankall$percd)]=0
      grankall$cs=cumsum(grankall$percd)-(grankall$percd/2)
      
      
      agrankall=rbind(agrankall,grankall)
    }
    
    rankcols=rev(brewer.pal(6, "Blues"))
    print(agrankall)
    print(
      ggplot(agrankall,aes(x=yearmonth,y=percd,ymax=1,fill=rankstr,label = gsub("^0%|^1%|^2%|^3%|^4%|^5%","",paste(round(percd*100,0),"%",sep=""))))+
        
        theme(legend.key.size = unit(1.5, "cm"))+
        geom_bar(stat="identity",position="stack")  +  
        scale_y_continuous(labels = percent) +ylab(label="")+xlab(label="") + geom_text(aes(y=c(cs)),position = position_identity(), hjust = 0.5, size=8) +
        ggtitle(paste(paste(agdentitysn,"Ranking on displayed profiles",coventity[k]),sep="\n\n"))+
        scale_fill_manual(values = rankcols) + labs(fill="") +  wtsl1
    )
    ggsave(paste(PathNamerank,file=paste("CI-RankingByMonth-",agdentitysn,"-",coventity[k],".png",sep=""),sep="/"),width=20,height=10,dpi=100)
    
  }
}

###function one Period stats for cacul all infos. Very important, allow to output all stats for cumulated evolution, for...
onePeriodStats <- function(res,w1,w2) {
  weeksLoc <- c(w1,w2)
  
  
  bigDB <- data.frame("insurer"=NaN,"coverage"=NaN,"period"=NaN,
                      "PlayerType"=NaN,"AvgEvolByProfile"=NaN,"ImpactedProfile"=NaN,
                      "AvgPremium"=NaN,
                      "AvgPremium_var"=NaN,
                      "Display_prop" = NaN,
                      "Display_var" = NaN,
                      "NbProfiles"=NaN)
  
  
  for (j in 1:length(formulaNames)){
    
    #     for (k in 1:length(Types)){
    
    formulaLoc <- formulaNames[j]
    
    
    groupLoc <- unique(res$insurer)
    
    # extraction of the local DB
    resloc0 <- res[which(res$period %in% weeksLoc),]
    resloc1 <- resloc0[which(resloc0$coverage %in% formulaMapping[formulaMapping[,1]==formulaLoc,2]),]
    resloc2 <- resloc1[which(resloc1$insurer%in% groupLoc),]
    resloc <- resloc2
    resW1 <- resloc[which(resloc$period %in% weeksLoc[1]),]
    resW2 <- resloc[which(resloc$period %in% weeksLoc[2]),]
    
    # initialization of quantites to be computed
    nLoc <- length(groupLoc)+1
    nbProfiles <- matrix(0,nLoc,4)
    nbProfiles[1,1] <- length(unique(resW1$profilID))
    nbProfiles[1,2] <- length(unique(resW2$profilID))
    avgPremium <- matrix(0,nLoc,3)
    byProfile <- matrix(0,nLoc,2)
    
    for (i in 1:length(groupLoc)) {
      # keep only data specific to the assureur company under study
      idxW1 <- which(resW1$insurer == groupLoc[i],arr.ind=T)
      idxW2 <- which(resW2$insurer == groupLoc[i],arr.ind=T) 
      resW1loc <- resW1[idxW1,]; resW2loc <- resW2[idxW2,]
      
      # modify 
      resW1loc <- subset(resW1loc,select=c(period,profilID,price))
      resW2loc <- subset(resW2loc,select=c(period,profilID,price))
      
      # average on same profilID queries (if so)
      resW1loc$price<- ave(resW1loc$price,resW1loc$profilID)
      resW2loc$price <- ave(resW2loc$price,resW2loc$profilID)
      
      
      resW1loc <- unique(resW1loc)
      resW2loc <- unique(resW2loc)
      
      # build usefull tab for computations
      r1merge <- resW1loc
      r2merge <- resW2loc
      colnames(r1merge) <- c("periode1","profilID","price1")
      colnames(r2merge) <- c("periode2","profilID","price2")
      usefullTab <- merge(r1merge,r2merge)
      usefullTab$diffP <- usefullTab$price2/usefullTab$price1-1
      
      # compute statistics
      
      byProfile[i+1,1] <- round(100*mean(usefullTab$diffP),2)
      byProfile[i+1,2] <- round(100*(sum(as.numeric(abs(usefullTab$diffP)>0))/length(usefullTab$profilID)),2)
      nbProfiles[i+1,1] <- length(resW1loc$profilID)
      nbProfiles[i+1,2] <- length(resW2loc$profilID)
      avgPremium[i+1,1] <- round(mean(resW1loc$price),0)
      avgPremium[i+1,2] <- round(mean(resW2loc$price),0)
      
      ## compute here relative display rate and rate rank among the groupLoc competitors
      
    }
    
    nbProfiles[,3] <- round(100*(nbProfiles[,2]/nbProfiles[1,2]),2)
    nbProfiles[,4] <- round(100*(nbProfiles[,2]/nbProfiles[,1]-1),2)
    avgPremium[,3] <- round(100*((avgPremium[,2]/avgPremium[,1])-1),2)
    
    rnames <- t(cbind("Total",t(groupLoc)))
    tabOut <- data.frame("AvgEvolByProfile"=byProfile[,1],
                         "ImpactedProfile"=byProfile[,2],
                         "AvgPremium"=avgPremium[,2],
                         "AvgPremium_var"=avgPremium[,3],
                         "Display_prop" = nbProfiles[,3],
                         "Display_var" = nbProfiles[,4],row.names = rnames,
                         "NbProfiles"=nbProfiles[,2])
    
    temp <- cbind("insurer"=groupLoc,"coverage"=rep(formulaLoc,nLoc-1),
                  "period"=rep(weeksLoc[2],nLoc-1),"PlayerType"="",tabOut[2:nLoc,])
    bigDB <- rbind(bigDB,temp)
    
  }
  
  bigDB <- data.frame(bigDB,row.names=NULL)
  bigDB <- na.omit(bigDB)
  return(bigDB);
}


####function for calcul variation between two periods### TODO: find where it is used.
evoloneperiod <- function(sum,p1,p2) {
  
  sum1=sum[sum$period==p1,]
  sum2=sum[sum$period==p2,]
  sumfinal=merge(sum1,sum2, by=("insurer"))
  
  sumfinal$var= sumfinal$cumevol.y- sumfinal$cumevol.x
  sumfinal=data.frame(sumfinal$insurer,sumfinal$var)
  
}


######## cumul evolution function######
####function for calcul variation###

#TODO: find where it is used
addplus <- function(var) {
  ifelse(var>0, paste("+", as.numeric(round(var,00)), sep=""),round(var,00))
}

#TODO: find where it is used
cumevolFunc <- function(rs){
  rs = rs/100
  cumrs = rs
  cumrs[1] = 100
  
  for (lm in 1:(length(cumrs))){
    cumrs[lm+1] = cumrs[lm]*(rs[lm]+1)
  }
  
  cumrs = cumrs-100
  cumrs = cumrs[2:length(cumrs)]
  cumrs
}


#TODO: find where it is used
cumulindex <- function(rs){
       cumrs=rs
       cumrs[1] = 100
  for (lm in 2:(length(rs))){
    cumrs[lm+1] = (cumrs[lm]+rs(lm+1))
  }
}



### function pour top 1 proportion by months and selected variable. Attention, not too much modalities!!!
top_propor_Generic <- function(tables,top = 1){
  
  
  ListFormulas=c(as.character(unique(tables$coverage)))
  
  ListPeriod=c(as.character(unique(tables$period)))
  
  for(i in 1:length(ListFormulas)){
    LocFomulas=ListFormulas[i]
    
    for (j in 1: length(ListPeriod)){
      LocPeriod=ListPeriod[j]
      
      temp=tables[tables$period==LocPeriod,]
      temp=temp[temp$coverage==LocFomulas,]
      
      temp=as.data.table(temp)
      temp[,rank:=rank(price,ties.method="first"),by=c("profilID","coverage","period","Segment")]
      r= 1:top 
      temp=temp[temp$rank%in%r,]
      temp=na.omit(temp)
      temp$ct=1
      
      temp[, cumsum:=lapply(.SD, sum), by = c("insurer","coverage","period","Segment"),.SDcols=c("ct")]
      temp[, cumsum2:=lapply(.SD, sum), by = c("coverage","period","Segment"),.SDcols=c("ct")]
      
      
      if(j==1)  {savefrdata=as.data.frame(temp)} else savefrdata=rbind(savefrdata,temp)
      rm(temp)
      
    }
    if(i==1)  {savefrdataTotal=as.data.frame(savefrdata)} else savefrdataTotal=rbind(savefrdataTotal,savefrdata)
    rm(savefrdata)
  }
  return(savefrdataTotal)
}


### Output generic graphs
top_Generic<- function(data,covfr, coveragenames = c("Top 1 MTPL","Top 1 MTPL EXT","Top 1 Full Co."), TitleComplement = "All Players", PathComplement = "1st Ranking Proportion by month all"){
  
  if(length(covfr) != length(coveragenames)){stop("Parameter covfr and coveragenames must have the same length!")}
  
  data$proportion=data$cumsum/data$cumsum2
  data$proportion=round(data$proportion*100)
  
  for(i in 1:length(covfr)){
    
    # coveragenames=c("Top 1 MTPL","Top 1 Full Co.")
    coverageapping <- cbind(coveragenames,covfr)
    
    datatemp=data[data$coverage==covfr[i],]
    
    datatemp=data.frame(datatemp$insurer,datatemp$coverage,datatemp$period,datatemp$proportion,datatemp$Segment)
    
    names(datatemp)=c("insurer","coverage","period","proportion","Segment")
    
    datatemp=datatemp[!duplicated(datatemp[c("coverage","period","insurer","proportion","Segment")]),]
    
    datatemp =datatemp[with(datatemp, order(coverage,desc(period),as.character(insurer),as.character(Segment))), ]
    
    datatemp=ddply(datatemp, .(coverage,period,Segment), mutate,csum = cumsum(proportion)-proportion/2)
    
    datatemp =datatemp[with(datatemp, order(desc(insurer),proportion,coverage,period,Segment,csum)), ]
    
    datatemp$insurer= factor(datatemp$insurer,levels=sort(levels(datatemp$insurer), TRUE))
    print(ggplot(datatemp,aes(x = period, y = proportion, fill = insurer,order=desc(insurer))) +
      theme(legend.key.size = unit(1, "cm"))+
      geom_bar(position = "fill",stat="identity") + facet_grid(.~Segment)+
      scale_fill_manual(values = colorpalette,name=coverageapping[i])+ scale_y_continuous(labels = percent_format()) + wtl+
      ggtitle(paste(paste(coveragenames[i],"Ranking Proportion by Month", TitleComplement,sep=" "),sep="\n\n"))+
      geom_text(aes(y = csum/100, label = paste(proportion,"%",sep="")), size =7, hjust = 0.5, vjust = 0,,stat="identity")+xlab("Month") + ylab("")
    )
    ggsave(paste(PathNamerank,file=paste(PathComplement,"-",covfr[i],".png",sep=""),sep="/"),width=20,height=14,dpi=100)
    
    
  }
}

###################### output graphs for checks#######################

#### function cumul graph#####

cumul_graphs=function(data,forNames,Typc,Typ,path){
  
  # write those tables for calculing the cumul price evolution 
  for (formulaLoc in forNames){
    
    for (typeLoc in Typ){
      s <- paste(typeLoc,"Players",sep="")
      s1 <- Typc$typesComplete[which(Typc$types == typeLoc)]
      groupLoc <- get(s)
      atx <- which(data$insurer %in% get(s) & data$coverage == formulaLoc)
      df <- data[atx,]
      result = data.frame(insurer = NaN,period = NaN, cumevol = NaN)
      for (kl in 1:length(groupLoc)) {
        dfperiodeLoc = df$period[which(df$insurer == groupLoc[kl])]
        tempp = length(dfperiodeLoc)
        repn = rep(groupLoc[kl],tempp)
        repw = dfperiodeLoc
        evolLoc = df$AvgEvolByProfile[which(df$insurer == groupLoc[kl])]
        if (length(evolLoc) == 0) {next}
        evolLocCum = cumevolFunc(evolLoc)
        resultloc = data.frame(insurer= repn, period=repw,cumevol=evolLocCum)
        result = rbind(result,resultloc)
        
        
        result = na.omit(result)
        DF_n = merge(df,result,by=intersect(names(df),names(result)))
        gname <- paste(s,formulaLoc,sep="_")
        
      }
      
      filename <- paste(s, formulaLoc,".csv", sep="")
      write.table(DF_n, file=paste("./output_MR_all",filename,sep="/"), col.names=TRUE,row.names=FALSE,sep=";",quote=FALSE)
      
      # cum evol graph
      print(DF_n)
      
      print(ggplot(DF_n,aes(period,cumevol,group=insurer),ymin=200)+
              geom_line(aes(colour=insurer),size=1.25)+
              xlab("Week")+ylab("Cumulated Average Evolution")+
              ggtitle(paste(paste(formulaLoc,"MRP sample - Cumulated Evolution"," "),s1,sep="\n\n"))+
              theme(plot.title = element_text(lineheight=.6, face="bold"))+
              scale_x_discrete("Week", labels = levels(DF_n$period))+
              #scale_y_continuous(limits = c(-10, 30))+
              theme(axis.text.x=element_text(angle=90))+
              labs(colour="Company",linetype="Company",shape="Company") +
              scale_colour_manual(values = colorpalette))
      
      #save the graph
      ggsave(paste(path,paste(paste("CUMEVOL",s,formulaLoc,sep="_"),"png",sep="."),sep="/"),
             scale = .8, width = 20,height = 10, units = "in") 
      
      
    }
  } 
}


#####average evolution function 

average_graphs=function(data,forNames,Typc,Typ,path){
  
  # write those tables for calculing the cumul price evolution 
  for (formulaLoc in forNames){
    
    for (typeLoc in Typ){
      s <- paste(typeLoc,"Players",sep="")
      s1 <- Typc$typesComplete[which(Typc$types == typeLoc)]
      groupLoc <- get(s)
      atx <- which(data$insurer %in% get(s) & data$coverage == formulaLoc)
      df <- data[atx,]
      result = data.frame(insurer = NaN,period = NaN, cumevol = NaN)
      for (kl in 1:length(groupLoc)) {
        dfperiodeLoc = df$period[which(df$insurer == groupLoc[kl])]
        tempp = length(dfperiodeLoc)
        repn = rep(groupLoc[kl],tempp)
        repw = dfperiodeLoc
        evolLoc = df$AvgEvolByProfile[which(df$insurer == groupLoc[kl])]
        if (length(evolLoc) == 0) {next}
        evolLocCum = cumevolFunc(evolLoc)
        resultloc = data.frame(insurer= repn, period=repw,cumevol=evolLocCum)
        result = rbind(result,resultloc)
        
        
        result = na.omit(result)
        df <- data.frame(df)
        DF_n = merge(df,result,by=intersect(names(df),names(result)))
        gname <- paste(s,formulaLoc,sep="_")
        
      }
      
      print(DF_n)
      print(ggplot(DF_n,aes(x=period,y=AvgPremium,group=insurer),ymin=200,height=500, width=800)+
              geom_line(aes(x=period,y=AvgPremium, colour = insurer,group=insurer),size=2,alpha=1)+
              xlab("Month")+ylab("Average Premium")+
              ggtitle(paste(paste(formulaLoc,"MRP sample - Average Premium"," "),sep=""))+
              theme(plot.title = element_text(lineheight=.6, face="bold"))+
              scale_fill_manual(values = colorpalette,name="insurer")+
              theme(axis.text.x=element_text(angle=80))+
              labs(colour="Company",linetype="Company",shape="Company")+
              scale_colour_manual(values = colorpalette))
      
      ggsave(paste(path, paste(paste("AVGPREMIUM",s,formulaLoc,sep="_"),"png",sep="."),sep="/"),
             scale = .8, width = 20,height = 10, units = "in")
      
    }
  } 
}

#####display function############ 

display_graphs=function(data,forNames,Typc,Typ,path){
  

  # write those tables for calculing the cumul price evolution 
  for (formulaLoc in forNames){
    
    for (typeLoc in Typ){
  
      
      s <- paste(typeLoc,"Players",sep="")
      s1 <- Typc$typesComplete[which(Typc$types == typeLoc)]
      groupLoc <- get(s)
      atx <- which(data$insurer %in% get(s) & data$coverage == formulaLoc)
      df <- data[atx,]
      result = data.frame(insurer = NaN,period = NaN, cumevol = NaN)
      for (kl in 1:length(groupLoc)) {
        dfperiodeLoc = df$period[which(df$insurer == groupLoc[kl])]
        tempp = length(dfperiodeLoc)
        repn = rep(groupLoc[kl],tempp)
        repw = dfperiodeLoc
        evolLoc = df$AvgEvolByProfile[which(df$insurer == groupLoc[kl])]
        if (length(evolLoc) == 0) {next}
        evolLocCum = cumevolFunc(evolLoc)
        resultloc = data.frame(insurer= repn, period=repw,cumevol=evolLocCum)
        result = rbind(result,resultloc)
        
        
        result = na.omit(result)
        df <- data.frame(df)
        DF_n = merge(df,result,by=intersect(names(df),names(result))) # this line can be the cause of a problem: vecseq...
        gname <- paste(s,formulaLoc,sep="_")
        
      }
      
      DF_n$numeric_periode<-as.numeric(as.factor(DF_n$period))
      last_week=max(DF_n$numeric_periode)
      weekListLocHalfYear = c(round(last_week/2,0):last_week)
      weekList1Year =c(1:last_week)
      weekList10week = c((last_week-9):last_week)
      #weekChoice <- weekListLocHalfYear # Enter as you want !!
      weekChoice <- weekList1Year # Enter as you want !!
      #weekChoice <- weekList10week # Enter as you want !!
      DF_new<-subset(DF_n,numeric_periode  %in%  weekChoice) 
      print(DF_new)
      print(ggplot(DF_new,aes(factor(period),insurer),height=600, width=800)+
              geom_point(aes(size = (2*Display_prop),colour = factor(insurer)),show_guide=FALSE)+
              scale_size(range = c(0, 20*min(max(10/length(weekChoice),0.5),1)))+
              xlab("Month")+ylab("")+
              ggtitle(paste(paste(formulaLoc,"MRP sample - Trend in Display Rate"," "),s1,sep="\n\n"))+
              theme(plot.title = element_text(lineheight=.6, face="bold"), 
                    text=element_text(size=10), axis.text.x = element_text(angle=90, vjust=1)) +
              scale_colour_manual(values = colorpalette))
      ggsave(paste(path,paste(paste("TRDDISPRATE",s,formulaLoc,sep="_"),"png",sep="."),sep="/"),
             scale = .8, width = 20,height = 10, units = "in")
      
    }
  } 
}


############## cumul log graphs


cumullog_graphs=function(data,forNames,Typc,Typ,path){
  
  # write those tables for calculing the cumul price evolution 
  for (formulaLoc in forNames){
    
    for (typeLoc in Typ){
      s <- paste(typeLoc,"Players",sep="")
      s1 <- Typc$typesComplete[which(Typc$types == typeLoc)]
      groupLoc <- get(s)
      atx =data[data$insurer %in% get(s) & data$coverage == formulaLoc,]
      
      print(ggplot(atx,aes(x=as.factor(unique(period)),y=mean,group=insurer),ymin=200,height=500, width=800)+
              geom_line(aes(x=as.factor(period),y=mean, colour = insurer,group=insurer),size=2,alpha=1)+
              xlab("Month")+ylab("Cumulated Average Evolution")+
              ggtitle(paste(paste(formulaLoc,"MRP sample - Cumulated Evolution"," "),s1,sep="\n\n"))+
              theme(plot.title = element_text(lineheight=.6, face="bold"))+
              scale_x_discrete("Week", labels = levels(as.factor(atx$period)))+
              scale_y_continuous(limits = c(-20, 20))+
              theme(axis.text.x=element_text(angle=90))+
              labs(colour="Company",linetype="Company",shape="Company") +
              scale_colour_manual(values = colorpalette))
      
      ggsave(paste(path, paste(paste("Clog",s,formulaLoc,sep="_"),"png",sep="."),sep="/"),
             scale = .8, width = 20,height = 10, units = "in")
      
    }
  }
}


############## log cumul evolution##############
onePeriodlog <- function(res,w1,w2) {
  weeksLoc <- c(w1,w2)
  Cumullogtable <- data.frame("profilID"=NaN,"insurer"=NaN,"coverage"=NaN,"period"=NaN,"LNEvolByProfile"=NaN)
  
  
  for (j in 1:length(formulaNames)){
    
    for (k in 1:length(Types)){
      
      formulaLoc <- formulaNames[j]
      typeLoc <- Types[k]
      s <- paste(typeLoc,"Players",sep="")
      groupLoc <- get(s)
      
      # extraction of the local DB
      resloc0 <- res[which(res$period %in% weeksLoc),]
      resloc1 <- resloc0[which(resloc0$coverage %in% formulaMapping[formulaMapping[,1]==formulaLoc,2]),]
      resloc2 <- resloc1[which(resloc1$insurer%in% groupLoc),]
      resloc <- resloc2
      resW1 <- resloc[which(resloc$period %in% weeksLoc[1]),]
      resW2 <- resloc[which(resloc$period %in% weeksLoc[2]),]
      
      for (i in 1:length(groupLoc)) {
        # keep only data specific to the assureur company under study
        idxW1 <- which(resW1$insurer == groupLoc[i],arr.ind=T)
        idxW2 <- which(resW2$insurer == groupLoc[i],arr.ind=T) 
        resW1loc <- resW1[idxW1,]; resW2loc <- resW2[idxW2,]
        # modify 
        resW1loc <- subset(resW1loc,select=c(coverage,insurer,period,profilID,price))
        resW2loc <- subset(resW2loc,select=c(coverage,insurer,period,profilID,price))
        
        # average on same profilID queries (if so)
        resW1loc$price<- ave(resW1loc$price,resW1loc$profilID)
        resW2loc$price <- ave(resW2loc$price,resW2loc$profilID)
        
        
        resW1loc <- unique(resW1loc)
        resW2loc <- unique(resW2loc)
        
        # build usefull tab for computations
        r1merge <- resW1loc
        r2merge <- resW2loc
        colnames(r1merge) <- c("coverage","insurer", "periode1","profilID","price1")
        colnames(r2merge) <- c("coverage","insurer","periode2","profilID","price2")
        usefullTab <- merge(r1merge,r2merge)
        
        usefullTab$diffP <- log(usefullTab$price2/usefullTab$price1,base=exp(1))
        usefullTab=na.omit(usefullTab)
        
        temp <- usefullTab
        temp1=subset(temp,select=c(profilID,insurer,coverage,periode2,diffP))
        names(temp1)=c("profilID","insurer","coverage","period","LNEvolByProfile")
        
        temp1=na.omit(temp1)
        if(i==1)  {temp2=as.data.frame(temp1)} else temp2=rbind(temp1,temp2)
        
      }
      
      Cumullogtable <- rbind(Cumullogtable,temp2)
      
    }
  }
  
  Cumullogtable <- data.frame(Cumullogtable,row.names=NULL)
  Cumullogtable <- na.omit(Cumullogtable)
  return(Cumullogtable);
}


#####cumulated evolution function 

cumevollogFunc <- function(rs){

  cumrs = rs
  cumrs[1] =0
  
  if (length(cumrs) == 1) {
    cumrs = rs}
  
  else{
    
  for (lm in 1:(length(cumrs)-1)){
    cumrs[lm+1] = cumrs[lm]+rs[lm+1]
  }
  }
  
  return(cumrs)
}


#############################################################function for MRH################################################################

##### take the BNP and DA price==== 
### take DA price 

price_extrat<-function(data,eco,confort,Name){
  
  DAprice_16=subset(data,select=c("CNT_ID", eco, confort))
  names(DAprice_16)=c("CNT_ID", "Basic Coverage" ,"Comfortable Coverage")
  
  DAprice_16=melt(DAprice_16, id=c("CNT_ID"))
  colnames(DAprice_16)[2]="coverage"
  colnames(DAprice_16)[3]="price"
  DAprice_16$insurer=Name
  DAprice_16$fees=0
  DAprice_16$profilID=matrix_HOME$profil_id[match(DAprice_16$CNT_ID, matrix_HOME$cnt_id)]
  DAprice_16=na.omit(DAprice_16)
  return(DAprice_16)
}

### take BNP price avec eco
price_extrat_BNPeco<-function(data,eco,confort,Name, sup){
  
  Bnppriceeco=subset(data,select=c("CNT_ID", eco,sup ))
  Bnppriceeco=Bnppriceeco[Bnppriceeco[,3]=="oui",]
  Bnppriceeco$coverage="La formule Essentielle"
  colnames(Bnppriceeco)[2]="price"
  Bnppriceeco=subset(Bnppriceeco,select=c(CNT_ID,coverage,price))
  length(unique(Bnppriceeco$CNT_ID))
  Bnppriceeco=subset(Bnppriceeco, select=c(CNT_ID, coverage,price ))
  
  Bnppriceconf=subset(data,select=c("CNT_ID",confort ))
  Bnppriceconf$coverage="La formule Confort"
  colnames(Bnppriceconf)[2]="price"
  Bnppriceconf=subset(Bnppriceconf,select=c(CNT_ID,coverage,price))
  length(unique(Bnppriceconf$CNT_ID))
  
  Bnpprice=rbind(Bnppriceeco, Bnppriceconf)
  
  Bnpprice$insurer=Name
  Bnpprice$fees=0
  Bnpprice$profilID=matrix_HOME$profil_id[match(Bnpprice$CNT_ID, matrix_HOME$cnt_id)]
  Bnpprice$formule_origine=matrix_HOME$formule_origine[match(Bnpprice$CNT_ID, matrix_HOME$cnt_id)]
  Bnpprice=na.omit(Bnpprice)
  
}

### function pour top 1 proportion by months####################
top1propor <- function(tables){
  
  ListFormulas=c(as.character(unique(tables$coverage)))
  
  ListPeriod=c(as.character(unique(tables$period)))
  
  for(i in 1:length(ListFormulas)){
    LocFomulas=ListFormulas[i]
    
    for (j in 1: length(ListPeriod)){
      LocPeriod=ListPeriod[j]
      
      temp=tables[tables$period==LocPeriod,]
      temp=temp[temp$coverage==LocFomulas,]
      
      temp=as.data.table(temp)
      temp[,rank:=rank(price,ties.method="first"),by=c("profilID","coverage","period")]
      r=c(1)
      temp=temp[temp$rank%in%r,]
      temp=na.omit(temp)
      temp$ct=1
      
      temp[, cumsum:=lapply(.SD, sum), by = c("insurer","coverage","period"),.SDcols=c("ct")]
      temp[, cumsum2:=lapply(.SD, sum), by = c("coverage","period"),.SDcols=c("ct")]
      
      
      if(j==1)  {savefrdata=as.data.frame(temp)} else savefrdata=rbind(savefrdata,temp)
      rm(temp)
      
    }
    if(i==1)  {savefrdataTotal=as.data.frame(savefrdata)} else savefrdataTotal=rbind(savefrdataTotal,savefrdata)
    rm(savefrdata)
  }
  return(savefrdataTotal)
}


### function for output top1 rank graphs
top1all<- function(data,covsp, nameinsurer, coveragenames){
  
  for(i in 1:length(covsp)){
    
    coveragenames=coveragenames
    coverageapping <- cbind(coveragenames,covsp)
    
    datatemp=data[data$coverage==covsp[i],]
    
    datatemp=data.frame(datatemp$insurer,datatemp$coverage,datatemp$period,datatemp$proportion)
    
    names(datatemp)=c("insurer","coverage","period","proportion")
    
    datatemp=datatemp[!duplicated(datatemp[c("coverage","period","insurer","proportion")]),]
    
    datatemp =datatemp[with(datatemp, order(coverage,desc(period),as.character(insurer))), ]
    
    datatemp=ddply(datatemp, .(coverage,period), mutate,csum = cumsum(proportion)-proportion/2)
    
    datatemp =datatemp[with(datatemp, order(insurer,proportion,coverage,csum)), ]
    
    datatemp$insurer= factor(datatemp$insurer,levels=sort(levels(datatemp$insurer), TRUE))
    #     
    ggplot(datatemp,aes(x = period, y = proportion, fill = insurer,order=desc(insurer))) +
      theme(legend.key.size = unit(0.8, "cm"))+
      geom_bar(position = "fill",stat="identity") + 
      scale_fill_manual(values = colorpalette,name=coverageapping[i])+ scale_y_continuous(labels = percent_format()) + wtsl1+
      #ggtitle(paste(paste("","TOP 1 Ranking Proportion ", nameinsurer),sep="\n\n"))+
      geom_text(aes(y = csum/100, label = paste(proportion,"%",sep="")), size = 12, hjust = 0.5, vjust = 0,stat="identity")+xlab("") + ylab("")
    
    ggsave(paste(PathNamerank,file=paste("Proportion of 1st Ranking by month ",nameinsurer,"-",covsp[i],".png",sep=""),sep="/"),width=15,height=12,dpi=100)
    
  }
}


### function for price gap and output 

price_gap<- function(data,month,cible){
  
  
  for(i in 1:length(month)){
    
    lthreeweek=data.frame(data)
    
    lthreeweek=lthreeweek[lthreeweek$yearmonth==month[i],]
    
    #select the market minimum price for last third months
    
    lthreeweekminmarket=lthreeweek[!grepl(cible,lthreeweek$insurer),]
    
    lthreeweekminmarket=lthreeweekminmarket[order(lthreeweekminmarket$price),]
    
    lthreeweekminmarket=lthreeweekminmarket[!duplicated(lthreeweekminmarket[c("profilID","coverage")]),]
    
    esdst=lthreeweek[grepl(cible, lthreeweek$insurer),]
    
    deltamineslast_third=merge(esdst,lthreeweekminmarket,by=c("profilID","coverage"))
    
    # calcul the delta
    deltamineslast_third$delta= (deltamineslast_third$price.x/deltamineslast_third$price.y)-1
    
    # calcul the delta
    deltaminesjan=subset(deltamineslast_third, select=c(profilID,coverage, insurer.x, price.x, yearmonth.x ,delta))
    names(deltaminesjan)=c( "profilID","coverage", "insurer", "price", "yearmonth" ,"delta")
    
    if(i==1)  {deltaminesfinal=as.data.frame(deltaminesjan)} else deltaminesfinal=rbind(deltaminesfinal,deltaminesjan)
    rm(deltaminesjan)
    
  }
  return(deltaminesfinal)
}


### output graphs#########



png_new<-function(Res, outputPath, Name,a,b){
  
  OutputName<-paste(Name,"Table", sep="")
  
  #   
  # Save as .png
  
  png(paste(outputPath,paste(OutputName,"png",sep="."),sep="/"),width=a,height=b,res=240  )
  
#   grid.table(Res, gpar.coretext = gpar(fontsize = 6, col = "black"),
#              
#              gpar.corefill = gpar(fill="aliceblue",alpha=0.10, col=NA),
#              
#              gpar.coltext = gpar(col = "black", fontsize = 6, fontface = "bold"),
#              
#              gpar.colfill = gpar(fill = "aliceblue", alpha=0.5, col = NA),
#              
#              gpar.rowtext = gpar(col = "black", fontsize = 6, fontface = "bold"),
#              
#              gpar.rowfill = gpar(fill = "aliceblue", alpha=0.5, col = NA),
#              
#              #h.even.alpha=0.50, h.odd.alpha=0.25,
#              
#              show.box=TRUE, show.vlines=TRUE , show.hlines=TRUE,
#              
#              show.colnames = TRUE,show.rownames = F)
  
  dev.off()}


################# price gap one vs one and output the mean tables

###### one vs one

price_gap_ovo<-function(ASSURLAND_HOME_DA_BNP,month,Name, Name1){
  
  ## define the scope
  select_insurers=c(Name, Name1)
  
  ASSURLAND_HOME_DA_BNP_scope=ASSURLAND_HOME_DA_BNP[ASSURLAND_HOME_DA_BNP$insurer%in%select_insurers & ASSURLAND_HOME_DA_BNP$period%in%month, ]
  
  pricegap_global=price_gap(ASSURLAND_HOME_DA_BNP_scope,month,Name)
  
  print(length(unique(pricegap_global[pricegap_global$coverage==covfr[1],]$profilID)))
  print(length(unique(pricegap_global[pricegap_global$coverage==covfr[2],]$profilID)))
  
  datainput=pricegap_global
  name=Name
  
  print(ggplot() +
          geom_density(aes(x=datainput$delta[datainput$coverage==covfr[1] & datainput$yearmonth==month[1]],y=(..count..)/sum(..count..)),colour="royalblue1",alpha = 0.5, size=1) +
          geom_density(aes(x=datainput$delta[datainput$coverage==covfr[2]& datainput$yearmonth==month[1]],y=(..count..)/sum(..count..)),colour="tomato", alpha = 0.5,size=1) +
          geom_density(aes(x=datainput$delta[datainput$coverage==covfr[1] & datainput$yearmonth==month[2]],y=(..count..)/sum(..count..)),colour="royalblue1",alpha = 0.8, size=1.5) +
          geom_density(aes(x=datainput$delta[datainput$coverage==covfr[2]& datainput$yearmonth==month[2]],y=(..count..)/sum(..count..)),colour="tomato", alpha = 0.8,size=1.5) +
          geom_density(aes(x=datainput$delta[datainput$coverage==covfr[1] & datainput$yearmonth==month[3]],y=(..count..)/sum(..count..)),colour="royalblue1",alpha = 1, size=2) +
          geom_density(aes(x=datainput$delta[datainput$coverage==covfr[2]& datainput$yearmonth==month[3]],y=(..count..)/sum(..count..)),colour="tomato", alpha = 1,size=2) +
          
          geom_vline(xintercept=0) +
          
          annotate("text", label = paste(covfr[1],month[1], sep=" "),colour= "royalblue1", x = 0.6, y = 0.0028, size=5,alpha = 0.5) +
          annotate("text", label = paste(covfr[2],month[1],sep=" "),colour= "tomato", x = 0.6,y = 0.0024, size=5,,alpha = 0.5) +
          annotate("text", label = paste(covfr[1],month[2], sep=" "),colour= "royalblue1", x = 0.6, y = 0.0020, size=5,alpha = 1) +
          annotate("text", label = paste(covfr[2],month[2],sep=" "),colour= "tomato", x = 0.6, y = 0.0016, size=5,,alpha = 1) +
          annotate("text", label = paste(covfr[1],month[3], sep=" "),colour= "royalblue1", x = 0.6, y = 0.0012, size=5,alpha = 1) +
          annotate("text", label = paste(covfr[2],month[3],sep=" "),colour= "tomato", x = 0.6, y = 0.0008, size=5,,alpha = 1) +
          
          wt +
          ggtitle(paste(paste(name,"VS", Name1," Price Gap",sep=" "),sep="\n\n\n")) +
          xlab(label = "")+ 
          ylab(label="% MRP")  + scale_x_continuous(labels = percent, breaks=seq(-30,30,0.2)))
  
  ggsave(paste(PathNamerank,file=paste(name, Name1,"CI-DeltaMin-Direct_all.png",sep="_"),sep="/"),width=16,height=9,dpi=100)
  
  ### out put table 
  
  delta1_left=datainput
  delta1_left=na.omit(delta1_left)
  sum_last_left1=data.frame("period"=unique(datainput$yearmonth)[1],"coverage"=unique(datainput$coverage), "mean"=0)
  sum_last_left2=data.frame("period"=unique(datainput$yearmonth)[2],"coverage"=unique(datainput$coverage), "mean"=0)
  sum_last_left3=data.frame("period"=unique(datainput$yearmonth)[3],"coverage"=unique(datainput$coverage), "mean"=0)
  
  sum_last_left=rbind(sum_last_left1,sum_last_left2,sum_last_left3)
  
  sum_last_left[sum_last_left$coverage==covfr[1]&sum_last_left$period==unique(datainput$yearmonth)[1],]$mean=round(mean(delta1_left[delta1_left$coverage==covfr[1]&delta1_left$yearmonth==unique(delta1_left$yearmonth)[1],]$delta)*100)
  sum_last_left[sum_last_left$coverage==covfr[1]&sum_last_left$period==unique(datainput$yearmonth)[2] ,]$mean=round(mean(delta1_left[delta1_left$coverage==covfr[1]& delta1_left$yearmonth==unique(delta1_left$yearmonth)[2],]$delta)*100)
  sum_last_left[sum_last_left$coverage==covfr[1]&sum_last_left$period==unique(datainput$yearmonth)[3] ,]$mean=round(mean(delta1_left[delta1_left$coverage==covfr[1]& delta1_left$yearmonth==unique(delta1_left$yearmonth)[3],]$delta)*100)
  
  sum_last_left[sum_last_left$coverage==covfr[2]&sum_last_left$period==datainput$yearmonth[1] ,]$mean=round(mean(delta1_left[delta1_left$coverage==covfr[2]&delta1_left$yearmonth==unique(delta1_left$yearmonth)[1],]$delta)*100)
  sum_last_left[sum_last_left$coverage==covfr[2]&sum_last_left$period==unique(datainput$yearmonth)[2] ,]$mean=round(mean(delta1_left[delta1_left$coverage==covfr[2]& delta1_left$yearmonth==unique(delta1_left$yearmonth)[2],]$delta)*100)
  sum_last_left[sum_last_left$coverage==covfr[2]&sum_last_left$period==unique(datainput$yearmonth)[3] ,]$mean=round(mean(delta1_left[delta1_left$coverage==covfr[2]& delta1_left$yearmonth==unique(delta1_left$yearmonth)[3],]$delta)*100)
  
#   png_new(sum_last_left,PathNamerank,paste("mean", name, Name1),600,600)
#   
}

###############
price_gap_ovo_v2<-function(ASSURLAND_HOME_DA_BNP,month,Name, Name1){
  
  ## define the scope
  select_insurers=c(Name, Name1)
  
  ASSURLAND_HOME_DA_BNP_scope=ASSURLAND_HOME_DA_BNP[ASSURLAND_HOME_DA_BNP$insurer%in%select_insurers & ASSURLAND_HOME_DA_BNP$period%in%month, ]
  
  pricegap_global=price_gap(ASSURLAND_HOME_DA_BNP_scope,month,Name)
  
  pricegap_global=pricegap_global[pricegap_global$delta<3.5,]
  
  print(length(unique(pricegap_global[pricegap_global$coverage==covfr[1],]$profilID)))
  print(length(unique(pricegap_global[pricegap_global$coverage==covfr[2],]$profilID)))
  
  datainput=pricegap_global
  name=Name
  
  print(ggplot() +
          geom_density(aes(x=datainput$delta[datainput$coverage==covfr[1] & datainput$yearmonth==month[1]],y=(..count..)/sum(..count..)),colour="royalblue1",alpha = 0.5, size=1) +
          geom_density(aes(x=datainput$delta[datainput$coverage==covfr[2]& datainput$yearmonth==month[1]],y=(..count..)/sum(..count..)),colour="tomato", alpha = 0.5,size=1) +
          geom_density(aes(x=datainput$delta[datainput$coverage==covfr[1] & datainput$yearmonth==month[2]],y=(..count..)/sum(..count..)),colour="royalblue1",alpha = 1, size=1.5) +
          geom_density(aes(x=datainput$delta[datainput$coverage==covfr[2]& datainput$yearmonth==month[2]],y=(..count..)/sum(..count..)),colour="tomato", alpha = 1,size=1.5) +
#           geom_density(aes(x=datainput$delta[datainput$coverage==covfr[1] & datainput$yearmonth==month[3]],y=(..count..)/sum(..count..)),colour="royalblue1",alpha = 1, size=2) +
#           geom_density(aes(x=datainput$delta[datainput$coverage==covfr[2]& datainput$yearmonth==month[3]],y=(..count..)/sum(..count..)),colour="tomato", alpha = 1,size=2) +
#           
          geom_vline(xintercept=0) +
          
          annotate("text", label = paste(covfr[1],month[1], sep=" "),colour= "royalblue1", x = 1, y = 0.0048, size=5,alpha = 0.5) +
          annotate("text", label = paste(covfr[2],month[1],sep=" "),colour= "tomato", x = 1,y = 0.0042, size=5,,alpha = 0.5) +
          annotate("text", label = paste(covfr[1],month[2], sep=" "),colour= "royalblue1", x = 1, y = 0.0036, size=5,alpha = 1) +
          annotate("text", label = paste(covfr[2],month[2],sep=" "),colour= "tomato", x = 1, y = 0.0030, size=5,,alpha = 1) +
#           annotate("text", label = paste(covfr[1],month[3], sep=" "),colour= "royalblue1", x = 0.6, y = 0.0012, size=5,alpha = 1) +
#           annotate("text", label = paste(covfr[2],month[3],sep=" "),colour= "tomato", x = 0.6, y = 0.0008, size=5,,alpha = 1) +          
          wt +
          ggtitle(paste(paste(name,"VS", Name1," Price Gap",sep=" "),sep="\n\n\n")) +
          xlab(label = "")+ 
          ylab(label="% MRP")  + scale_x_continuous(labels = percent, breaks=seq(-50,50,0.5)))
  
  ggsave(paste(PathNamerank,file=paste(name, Name1,"CI-DeltaMin-Direct_all.png",sep="_"),sep="/"),width=16,height=9,dpi=100)
  
  ### out put table 
  
  delta1_left=datainput
  delta1_left=na.omit(delta1_left)
  sum_last_left1=data.frame("period"=unique(datainput$yearmonth)[1],"coverage"=unique(datainput$coverage), "mean"=0)
  sum_last_left2=data.frame("period"=unique(datainput$yearmonth)[2],"coverage"=unique(datainput$coverage), "mean"=0)
#   sum_last_left3=data.frame("period"=unique(datainput$yearmonth)[3],"coverage"=unique(datainput$coverage), "mean"=0)
#   
  sum_last_left=rbind(sum_last_left1,sum_last_left2)
  
  sum_last_left[sum_last_left$coverage==covfr[1]&sum_last_left$period==unique(datainput$yearmonth)[1],]$mean=round(mean(delta1_left[delta1_left$coverage==covfr[1]&delta1_left$yearmonth==unique(delta1_left$yearmonth)[1],]$delta)*100)
  sum_last_left[sum_last_left$coverage==covfr[1]&sum_last_left$period==unique(datainput$yearmonth)[2] ,]$mean=round(mean(delta1_left[delta1_left$coverage==covfr[1]& delta1_left$yearmonth==unique(delta1_left$yearmonth)[2],]$delta)*100)
#   sum_last_left[sum_last_left$coverage==covfr[1]&sum_last_left$period==unique(datainput$yearmonth)[3] ,]$mean=round(mean(delta1_left[delta1_left$coverage==covfr[1]& delta1_left$yearmonth==unique(delta1_left$yearmonth)[3],]$delta)*100)
  
  sum_last_left[sum_last_left$coverage==covfr[2]&sum_last_left$period==datainput$yearmonth[1] ,]$mean=round(mean(delta1_left[delta1_left$coverage==covfr[2]&delta1_left$yearmonth==unique(delta1_left$yearmonth)[1],]$delta)*100)
  sum_last_left[sum_last_left$coverage==covfr[2]&sum_last_left$period==unique(datainput$yearmonth)[2] ,]$mean=round(mean(delta1_left[delta1_left$coverage==covfr[2]& delta1_left$yearmonth==unique(delta1_left$yearmonth)[2],]$delta)*100)
#   sum_last_left[sum_last_left$coverage==covfr[2]&sum_last_left$period==unique(datainput$yearmonth)[3] ,]$mean=round(mean(delta1_left[delta1_left$coverage==covfr[2]& delta1_left$yearmonth==unique(delta1_left$yearmonth)[3],]$delta)*100)
  
#   png_new(sum_last_left,PathNamerank,paste("mean", name, Name1),600,600)
write.table(sum_last_left, file=paste(PathNamerank,paste(Name1,"mean.csv", sep="_"),sep="/"), col.names=TRUE,row.names=FALSE,sep=";",quote=FALSE)

}


# function pour top 1 proportion by segment
top1propor_segment<- function(tables){
  
  ListFormulas=c(as.character(unique(tables$coverage)))
  
  ListPeriod=c(as.character(unique(tables$period)))
  
  for(i in 1:length(ListFormulas)){
    LocFomulas=ListFormulas[i]
    
    for (j in 1: length(ListPeriod)){
      LocPeriod=ListPeriod[j]
      
      temp=tables[tables$period==LocPeriod,]
      temp=temp[temp$coverage==LocFomulas,]
      
      temp=as.data.table(temp)
      temp[,rank:=rank(price,ties.method="first"),by=c("profilID","coverage","period","segment")]
      r=c(1)
      temp=temp[temp$rank%in%r,]
      temp=na.omit(temp)
      temp$ct=1
      
      temp[, cumsum:=lapply(.SD, sum), by = c("insurer","coverage","period","segment"),.SDcols=c("ct")]
      temp[, cumsum2:=lapply(.SD, sum), by = c("coverage","period","segment"),.SDcols=c("ct")]
      
      
      if(j==1)  {savefrdata=as.data.frame(temp)} else savefrdata=rbind(savefrdata,temp)
      rm(temp)
      
    }
    if(i==1)  {savefrdataTotal=as.data.frame(savefrdata)} else savefrdataTotal=rbind(savefrdataTotal,savefrdata)
    rm(savefrdata)
  }
  return(savefrdataTotal)
}

##############

profil_number<- function(data,seg_name,insurer_name, month){

nprofiles_occupanttype_hometype3=subset(data,select=c(coverage,segment,cumsum2,period))
nprofiles_occupanttype_hometype3=data.frame(nprofiles_occupanttype_hometype3)
nprofiles_occupanttype_hometype3=nprofiles_occupanttype_hometype3[!duplicated(nprofiles_occupanttype_hometype3[c("segment","coverage","cumsum2","period")]),]

nprofiles_occupanttype_hometype3=nprofiles_occupanttype_hometype3[order(nprofiles_occupanttype_hometype3$coverage, nprofiles_occupanttype_hometype3$segment),]
names(nprofiles_occupanttype_hometype3)=c("Coverage","segment","Profils_Number","period")

nprofiles_occupanttype_hometype_ess3=nprofiles_occupanttype_hometype3[nprofiles_occupanttype_hometype3$Coverage==covfr[1],]

nprofiles_occupanttype_hometype_confort3=nprofiles_occupanttype_hometype3[nprofiles_occupanttype_hometype3$Coverage==covfr[2],]

total_occupanttype_hometype3=merge(nprofiles_occupanttype_hometype_ess3,nprofiles_occupanttype_hometype_confort3,by=c("segment","period"))

total_occupanttype_hometype3=subset(total_occupanttype_hometype3,select=c(segment,Profils_Number.x,Profils_Number.y,period))
names(total_occupanttype_hometype3)=c("segment", "Essentielle_Profils_Number","Confort_Profils_Number","period")


total_occupanttype_hometype3=total_occupanttype_hometype3[total_occupanttype_hometype3$period==max(month),]
png_new(total_occupanttype_hometype3,PathNameseg,paste("nprofiles", seg_name, insurer_name,sep="_"),950,700)

}

## function for output segment graphs
rankseg_output_segment <- function(data, name, output){
  
  for(i in 1:length(covfr)){
    formule=covfr[i]
    
    age_top1_all=data[data$coverage==formule,]
    
    age_top1_all=data.frame(age_top1_all$insurer,age_top1_all$coverage,age_top1_all$period,age_top1_all$proportion,age_top1_all$segment)
    names(age_top1_all)=c("insurer","coverage","period","proportion","segment")
    
    age_top1_all=age_top1_all[!duplicated(age_top1_all[c("insurer","coverage","period","proportion","segment")]),]
    
    age_top1_all =age_top1_all[with(age_top1_all, order(coverage,desc(insurer),as.character(insurer))), ]
    
    age_top1_all=ddply(age_top1_all, .(coverage,period,segment), mutate,csum = cumsum(proportion)-proportion/2)
    
   age_top1_all =age_top1_all[with(age_top1_all, order(desc(insurer),proportion,coverage,csum)), ]
    age_top1_all$insurer= factor(age_top1_all$insurer,levels=sort(levels(age_top1_all$insurer), TRUE))
    #  
    
    print(ggplot(age_top1_all,aes(x = period, y = proportion, fill = insurer,order=insurer)) +
            geom_bar(position = "fill",stat="identity") +   facet_grid(.~segment)+
            scale_fill_manual(values = colorpalette,name=paste("Top 1 ", formule, sep=""))+ scale_y_continuous(labels = percent_format()) + wtsl+
            #ggtitle(paste(paste("","TOP 1 Ranking Proportion by Month and Age All Players"),sep="\n\n"))+
            geom_text(aes(y = csum/100, label = paste(proportion,"%",sep="")), size = 8, hjust = 0.5, vjust = 0)+xlab("") + ylab("")) 
    
    ggsave(paste(output,file=paste("1st Ranking Proportion by ", name,"-",formule,".png",sep=""),sep="/"),width=22,height=10,dpi=100)
    
  }
}

### price distribution#################


## price_changes function 
price_changes<- function(res,insurer1,insurer2,w1,w2) {
  
  w1=res[res$period==w1& res$insurer==insurer1,]
  w2=res[res$period==w2& res$insurer==insurer2,]
  
  w12=merge(w1,w2, by=c("profilID","coverage","insurer"))
  w12$delta=w12$price.y/w12$price.x-1
  w12$delta=round(w12$delta*100,2)
  
  return(w12)
  
}


###output summary tables
output_summary_csv<- function(table1) {
  
  out=as.matrix(summary(table1$delta))
  colnames(out)="value"
  out=t(out)
  
  write.table(out, paste(PathNameevol,paste(unique(table1$coverage), "summary.csv", sep="_"),sep="/"), col.names=TRUE,row.names=FALSE,sep=";",quote=FALSE)
}

###output summary tables
output_summary<- function(table1) {
  
  out=as.matrix(summary(table1$delta))
  colnames(out)="value"
  out=t(out)
  
  write.table(out, paste(PathNameevol,paste(unique(table1$coverage), "summary.csv", sep="_"),sep="/"), col.names=TRUE,row.names=FALSE,sep=";",quote=FALSE)
  
  ## output images
  Res=out
  OutputName<-paste(unique(table1$insurer),unique(table1$coverage),"Delta_summary", sep="_")
  png(paste(PathNameevol,paste(OutputName,"png",sep="."),sep="/"),width=800,height=180,res=250)
  
  grid.table(Res, gpar.coretext = gpar(fontsize = 6, col = "black"),
             
             gpar.corefill = gpar(fill="aliceblue",alpha=0.10, col=NA),
             
             gpar.coltext = gpar(col = "black", fontsize = 6, fontface = "bold"),
             
             gpar.colfill = gpar(fill = "aliceblue", alpha=0.5, col = NA),
             
             #h.even.alpha=0.50, h.odd.alpha=0.25,
             
             show.box=TRUE, show.vlines=TRUE , show.hlines=FALSE,
             
             show.rownames = FALSE, show.colnames = TRUE)
  
  dev.off()
}

####output distribution graphs

output_delta_distribution<- function(data,coverage,break1,break2,histogram_break) {
  
  for (k in 1:length(coverage)) {
    
    data1=data[data$coverage==coverage[k], ]
    
    data1=data1[data1$delta>break1 & data1$delta< break2 ,]
    
    p1rctrd1=density(x=data1$delta,bw="sj")
    
    h<-hist(data1$delta, breaks=histogram_break) 
    
    png(filename=paste(PathNameevol,paste(unique(data1$insurer),coverage[k],unique(data1$period), "Price differences.png",sep="_"),sep="/"),width = 760, height = 700);
    
    
    h<-hist(data1$delta,freq=FALSE, breaks=histogram_break, col="lightgreen",ylim=c(0, .050),main="",xlab="")
    lines(p1rctrd1,col="darkblue",lwd = 2,main="")
    title(paste("Price Changes Distribution",paste(unique(data1$insurer),coverage[k],sep=" / "),sep="\n"),cex.main =2) 
    
    dev.off ();
    
  }
}


#### Tree functions#####
Decision_Tree <- function(data,name){
  
  
  arbre<-ctree(reponse~., data=data,controls = ctree_control(maxdepth = 5, minbucket=50))
  
  plot(arbre,ip_args = list(fill = c("#a6bddb")),tp_args = list(col=c("black"), fill = c("#2c7fb8","white")))
  
  print(arbre)
  
  if(class(data$reponse)=="factor"){
    
    jpeg(filename = paste(PathNameDT,paste(paste(name,covfr[i],sep="-"), "jpg", sep="."),sep="/"), width = 4000, height = 2000, pointsize = 12, quality = 75, bg = "white", res = 200)
    
    plot(arbre, ip_args = list(fill = c("#a6bddb")),tp_args = list(col=c("black"), fill = c("#2c7fb8","white")))
    
    
    dev.off()
    
    
  }else if (class(data$reponse)=="numeric"){
    
    jpeg(filename = paste(PathNameDT,paste(paste(name,covfr[i],sep="-"), "jpg", sep="."),sep="/"), width = 4000, height = 2000, pointsize = 12, quality = 75, bg = "white", res = 200)
    
    plot(arbre, ip_args = list(fill = c("#a6bddb")),tp_args = list(col=c("black"), fill = c("#2c7fb8","white")))
    
    dev.off()
    
  }
  
}


##############

## take the 
macif_data <-function(data)
{
  macif_a=subset(data, select=c( Profile.No., Predicted.Premium))
  names(macif_a)=c("profilID", "price")
  macif_a$price=as.numeric(as.character(macif_a$price))
  macif_a=na.omit(macif_a)
  return(macif_a) 
}


####
pacifica_data <-function(data)
{
  
  data=subset(data, select=c( Profile.No.,Initial,   Integral))
  names(data)=c("profilID", "Basic Coverage", "Comfortable Coverage")
  
  data=melt(data, id=c("profilID"))
  
  names(data)=c("profilID","coverage", "price")
  
  data$price=as.numeric(as.character(data$price))
  
  data=na.omit(data)
  
  data$insurer="Pacifica"
  ## mensuel turn into annule 
  data$price=data$price*12
  
  return(data)
}

