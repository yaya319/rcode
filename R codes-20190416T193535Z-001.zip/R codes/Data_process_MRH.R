
# 
# save(matrix_HOME, file = "./mapping_table/downloaddata/matrix_HOME.RData")
# save(ASSURLAND_HOME, file = "./mapping_table/downloaddata/ASSURLAND_HOME.RData")

load("./mapping_table/downloaddata/matrix_HOME.Rdata" )
load("./mapping_table/downloaddata//ASSURLAND_HOME.Rdata" )


matrix_HOME=matrix_HOME[matrix_HOME$level=="MRH201507",]
### crawling data====
## name yearmonth variable
ASSURLAND_HOME$yearmonth <- paste( "Y",substr(ASSURLAND_HOME$year,3,4), "M",formatC(ASSURLAND_HOME$month,width=2, flag="0") , sep = "")
table(ASSURLAND_HOME$yearmonth)
ASSURLAND_HOME$period=ASSURLAND_HOME$yearmonth

## select only the useful variables
ASSURLAND_HOME=subset(ASSURLAND_HOME, select=c(profilID, insurer, coverage, prix, status,period, yearmonth))
colnames(ASSURLAND_HOME)[4]="price"

## check the price
summary(ASSURLAND_HOME$price)

## remove the invalide price
ASSURLAND_HOME=ASSURLAND_HOME[!ASSURLAND_HOME$price==0,]
summary(ASSURLAND_HOME$price)

# variable formule origine for each profil
ASSURLAND_HOME$formule_origine=matrix_HOME$formule_origine[match(ASSURLAND_HOME$profilID,matrix_HOME$profil_id)]
## mapping for the coverages
ASSURLAND_HOME$coveage1=ifelse(ASSURLAND_HOME$coverage== "La formule Essentielle", "Basic Coverage" ,
                                   ifelse(ASSURLAND_HOME$coverage== "La formule Confort", "Comfortable Coverage", "non"))

ASSURLAND_HOME=ASSURLAND_HOME[ASSURLAND_HOME$coveage1%in%c("Basic Coverage" ,"Comfortable Coverage"),]
ASSURLAND_HOME$insurer=as.character(ASSURLAND_HOME$insurer)

### crawling PNO

PNO_price=read.csv2("./mapping_table/MRP/201609/Mario/PNO_price.csv",header=T,sep=";",dec=".")

PNO_price$coverage="PNO"

PNO_price=data.frame(profilID=PNO_price$profilID, insurer=PNO_price$insurer, coverage=PNO_price$coverage, price=PNO_price$prix, period="Y16M09", yearmonth="Y16M09")

## calculate display rate for both coverages 
tauxess=length(unique(ASSURLAND_HOME[ASSURLAND_HOME$coveage1=="Basic Coverage"  ,]$profilID))/length(unique(ASSURLAND_HOME$profilID))
tauxcon= length(unique(ASSURLAND_HOME[ASSURLAND_HOME$coveage1=="Comfortable Coverage" ,]$profilID))/length(unique(ASSURLAND_HOME$profilID))
length(unique(PNO_price[PNO_price$coverage=="PNO" ,]$profilID))

tauxess #42%
tauxcon #58%


ASSURLAND_HOME=subset(ASSURLAND_HOME, select=c(profilID,insurer,coveage1,price,period, yearmonth))
names(ASSURLAND_HOME)=c("profilID","insurer","coverage","price","period", "yearmonth")
ASSURLAND_HOME=rbind(ASSURLAND_HOME, PNO_price)

#################################### DA price##################################
## DA price: V59 of legacy
New_price=read.csv2("./mapping_table/MRP/201609/DA_tarifv59.csv",header=T,sep=";",dec=".")
### take DA price 
DAprice_16=price_extrat(New_price, "pttc_da_Eco", "pttc_da_confort_sans_del","Direct Assurance")
DAprice_16$period="Y16M09"
DAprice_16$yearmonth="Y16M09"

DAprice_16=subset(DAprice_16, select=c(profilID,insurer,coverage, price ,period, yearmonth))

## PNO
legacyF5=read.csv2("./mapping_table/MRP/201609/Mario/tarif_Mario_light_v1120160914_F5.csv",header=T,sep=";",dec=".")
legacyF5=subset(legacyF5, select=c(idcnt, pttc_ho_v59 ))
legacyF5$coverage="PNO"
legacyF5$period="Y16M09"
legacyF5$yearmonth="Y16M09"
legacyF5$insurer="Direct Assurance"

## profils pno
matrixF5=read.csv2("./mapping_table/MRP/201609/Mario/PNO_profils.csv",header=T,sep=";",dec=".")
matrixF5=data.table(matrixF5)
legacyF5$profilID=matrixF5$profil_id[match(legacyF5$idcnt,matrixF5$cnt_id)]
legacyF5$formule_origine=4
legacyF5=na.omit(legacyF5)

legacyF5=data.frame("profilID"=legacyF5$profilID,"insurer"=legacyF5$insurer, "coverage"=legacyF5$coverage, "price"=legacyF5$pttc_ho_v59, "period"=legacyF5$period, "yearmonth"=legacyF5$yearmonth)
legacy=rbind(ASSURLAND_HOME, DAprice_16, legacyF5)

#############################201609 tarrif Mario#####################################

# ## version 9: pttc_ho_tot_leg
# 
# mario_newproductF2=read.csv2("./mapping_table/MRP/201609/Mario/tarif_Mario_light20160914_F2.csv",header=T,sep=";",dec=".")
# mario_newproductF2=mario_newproductF2[mario_newproductF2$Formula=="Economique",]
# mario_newproductF2=subset(mario_newproductF2, select=c(idcnt, pttc_ho_tot_leg))
# mario_newproductF2$coverage="Basic Coverage"
# 
# mario_newproductF3=read.csv2("./mapping_table/MRP/201609/Mario/tarif_Mario_light20160914_F3.csv",header=T,sep=";",dec=".")
# mario_newproductF3=mario_newproductF3[mario_newproductF3$Formula=="Confort",]
# mario_newproductF3=subset(mario_newproductF3, select=c(idcnt, pttc_ho_tot_leg ))
# mario_newproductF3$coverage="Comfortable Coverage"
# mario_newproductF3=na.omit(mario_newproductF3)
# 
# mario_newproductF2=data.table(mario_newproductF2)
# mario_newproductF2$profilID=matrix_HOME$profil_id[match(matrix_HOME$cnt_id,mario_newproductF2$idcnt)]
# mario_newproductF2$formule_origine=matrix_HOME$formule_origine[match(matrix_HOME$profil_id,mario_newproductF2$profilID)]
# 
# mario_newproductF3=data.table(mario_newproductF3)
# mario_newproductF3$profilID=matrix_HOME$profil_id[match(matrix_HOME$cnt_id,mario_newproductF3$idcnt)]
# mario_newproductF3$formule_origine=matrix_HOME$formule_origine[match(matrix_HOME$profil_id,mario_newproductF3$profilID)]
# 
# mario_162=rbind(mario_newproductF2,mario_newproductF3)
#   
# mario_162=data.frame("profilID"=mario_162$profilID, "coverage"=mario_162$coverage, "price"=mario_162$pttc_ho_tot_leg )
# mario_162$yearmonth="Y16M09_Mariov9"
# mario_162$insurer="Direct Assurance"    
# mario_162$period="Y16M09_Mariov9"
# 
# ## tarif competitors
# ASSURLAND_HOME_mario=ASSURLAND_HOME
# ASSURLAND_HOME_mario$period="Y16M09_Mariov9"
# ASSURLAND_HOME_mario$yearmonth="Y16M09_Mariov9"


## version 11: pttc_ho_tot_leg_att

mariov10_newproductF2=read.csv2("./mapping_table/MRP/201609/Mario/tarif_Mario_light_v1120160914_F2.csv",header=T,sep=";",dec=".")
mariov10_newproductF2=mariov10_newproductF2[mariov10_newproductF2$Formula=="Economique",]
mariov10_newproductF2=subset(mariov10_newproductF2, select=c(idcnt, pttc_ho_tot_leg_att))
mariov10_newproductF2$coverage="Basic Coverage"

mariov10_newproductF3=read.csv2("./mapping_table/MRP/201609/Mario/tarif_Mario_light_v1120160914_F3.csv",header=T,sep=";",dec=".")
mariov10_newproductF3=mariov10_newproductF3[mariov10_newproductF3$Formula=="Confort",]
mariov10_newproductF3=subset(mariov10_newproductF3, select=c(idcnt, pttc_ho_tot_leg_att ))
mariov10_newproductF3$coverage="Comfortable Coverage"
mariov10_newproductF3=na.omit(mariov10_newproductF3)

mariov10_newproductF2=data.table(mariov10_newproductF2)
mariov10_newproductF2$profilID=matrix_HOME$profil_id[match(matrix_HOME$cnt_id,mariov10_newproductF2$idcnt)]
mariov10_newproductF2$formule_origine=matrix_HOME$formule_origine[match(matrix_HOME$profil_id,mariov10_newproductF2$profilID)]

mariov10_newproductF3=data.table(mariov10_newproductF3)
mariov10_newproductF3$profilID=matrix_HOME$profil_id[match(matrix_HOME$cnt_id,mariov10_newproductF3$idcnt)]
mariov10_newproductF3$formule_origine=matrix_HOME$formule_origine[match(matrix_HOME$profil_id,mariov10_newproductF3$profilID)]

mariov10_newproductF5=read.csv2("./mapping_table/MRP/201609/Mario/tarif_Mario_light_v1120160914_F5.csv",header=T,sep=";",dec=".")
mariov10_newproductF5=mariov10_newproductF5[mariov10_newproductF5$Formula=="Pno",]
mariov10_newproductF5=subset(mariov10_newproductF5, select=c(idcnt, pttc_ho_tot_leg_att ))
mariov10_newproductF5$coverage="PNO"
mariov10_newproductF5=na.omit(mariov10_newproductF5)

## profils pno
matrixF5=read.csv2("./mapping_table/MRP/201609/Mario/PNO_profils.csv",header=T,sep=";",dec=".")
matrixF5=data.table(matrixF5)
mariov10_newproductF5$profilID=matrixF5$profil_id[match(mariov10_newproductF5$idcnt,matrixF5$cnt_id)]
mariov10_newproductF5$formule_origine=4
mariov10_newproductF5=na.omit(mariov10_newproductF5)

mario_10=rbind(mariov10_newproductF2,mariov10_newproductF3,mariov10_newproductF5)

mario_10=data.frame("profilID"=mario_10$profilID, "coverage"=mario_10$coverage, "price"=mario_10$pttc_ho_tot_leg_att )
mario_10$yearmonth="Y16M09_Mario"
mario_10$insurer="Direct Assurance"    
mario_10$period="Y16M09_Mario"

## tarif competitors
ASSURLAND_HOME_mariov10=ASSURLAND_HOME
ASSURLAND_HOME_mariov10$period="Y16M09_Mario"
ASSURLAND_HOME_mariov10$yearmonth="Y16M09_Mario"

Mario=rbind(mario_10, ASSURLAND_HOME_mariov10)

############################ MACIF + Pacifca

macif_appart=read.csv2("Z:/Users/Y.LI/Bechmarks/Reverse/Macif/MACIF_APARTMENT/macif_price_appart_MRP.csv",header=T,sep=";",dec=".")
macif_house=read.csv2("Z:/Users/Y.LI/Bechmarks/Reverse/Macif/MACIF_HOUSE/macif_price_house_MRP.csv",header=T,sep=";",dec=".")
macif_ess_appart=read.csv2("Z:/Users/Y.LI/Bechmarks/Reverse/Macif/MACIF_APARTMENT/macif_price_ess_appart_MRP.csv",header=T,sep=";",dec=".")

## take the 
macif_data <-function(data)
{
  macif_a=subset(data, select=c( Profile.No., Predicted.Premium))
  names(macif_a)=c("profilID", "price")
  macif_a$price=as.numeric(as.character(macif_a$price))
  macif_a=na.omit(macif_a)
  return(macif_a) 
}

macif_appart=macif_data(macif_appart)
macif_house=macif_data(macif_house)
macif=rbind(macif_house, macif_appart)
macif$coverage="Comfortable Coverage"
macif$insurer="Macif"


macif_ess_appart=macif_data(macif_ess_appart)
macif_ess_appart$coverage="Basic Coverage"
macif_ess_appart$insurer="Macif"
macif=rbind(macif, macif_ess_appart)


## pacifica price
pacifica_house=read.csv2("Z:/Users/Y.LI/Bechmarks/Reverse/Pacifica/House/pacifica_house_price_MRP.csv",header=T,sep=";",dec=".")
pacifica_house=subset(pacifica_house, select=c( Profile.No.,Initial,   Integral))

pacifica_appart=read.csv2("Z:/Users/Y.LI/Bechmarks/Reverse/Pacifica/Apartement/pacifica_price_appart_MRP.csv",header=T,sep=";",dec=".")
pacifica_appart=subset(pacifica_appart, select=c( Profile.No.,Initial,   Integral))

pacifica_pno=read.csv2("./mapping_table/MRP/201609/Mario/pacifica_MRP_PNO.csv",header=T,sep=";",dec=".")
pacifica_pno=subset(pacifica_pno, select=c(profil_id,   pacifica.initial))
names(pacifica_pno)=c(  "profilID",   "price")
pacifica_pno$coverage="PNO"
pacifica_pno$insurer="Pacifica"

pacifica=rbind(pacifica_house, pacifica_appart)

pacifica_data <-function(data)
{

data=subset(data, select=c( Profile.No.,Initial,   Integral))
names(data)=c("profilID", "Basic Coverage", "Comfortable Coverage")

data=melt(data, id=c("profilID"))

names(data)=c("profilID","coverage", "price")

data$price=as.numeric(as.character(data$price))

data=na.omit(data)

data$insurer="Pacifica"
## mensuel turn into annule 
data$price=data$price*12

return(data)
}

pacifica1=pacifica_data(pacifica)


### check pacifica
length(unique(pacifica1[pacifica1$coverage=="Basic Coverage",]$profilID))
length(unique(pacifica1[pacifica1$coverage=="Comfortable Coverage",]$profilID))

summary(pacifica1[pacifica1$coverage=="Basic Coverage",]$price)
summary(pacifica1[pacifica1$coverage=="Comfortable Coverage",]$price)

## check Macif 

length(unique(macif[macif$coverage=="Basic Coverage",]$profilID))
length(unique(macif[macif$coverage=="Comfortable Coverage",]$profilID))

summary(macif[macif$coverage=="Basic Coverage",]$price)
summary(macif[macif$coverage=="Comfortable Coverage",]$price)


macif_pacifica=rbind(macif, pacifica1)

macif_pacifica$profilID_new=matrix_HOME$profil_id[match(macif_pacifica$profilID,matrix_HOME$cnt_id)]

macif_pacifica$profilID=macif_pacifica$profilID_new

pacifica_pno$profilID_new=pacifica_pno$profilID
macif_pacifica=rbind(macif_pacifica, pacifica_pno)

## cr�er des p�riodes 
macif_pacifica2=macif_pacifica
macif_pacifica2$period="Y16M09"
macif_pacifica2$yearmonth="Y16M09"
macif_pacifica2=subset(macif_pacifica2, select=c(profilID,insurer,coverage, price ,period, yearmonth))

## cr�er des p�riodes 
macif_pacifica3=macif_pacifica
macif_pacifica3$period="Y16M09_Mario"
macif_pacifica3$yearmonth="Y16M09_Mario"
macif_pacifica3=subset(macif_pacifica3, select=c(profilID,insurer,coverage, price ,period, yearmonth))


# profilID list by coverage: find the commun profiles between macif pacifca and crawling 
list_basic_coverage=intersect(unique(macif_pacifica[macif_pacifica$coverage=="Basic Coverage",]$profilID), unique(ASSURLAND_HOME[ASSURLAND_HOME$coverage=="Basic Coverage",]$profilID))
list_comfortable_coverage=intersect(unique(macif_pacifica[macif_pacifica$coverage=="Comfortable Coverage",]$profilID), unique(ASSURLAND_HOME[ASSURLAND_HOME$coverage=="Comfortable Coverage",]$profilID))

legacy_basic=legacy[legacy$coverage=="Basic Coverage", ]
legacy_comfortable=legacy[legacy$coverage=="Comfortable Coverage", ]
legacy_basic=legacy_basic[legacy_basic$profilID%in%list_basic_coverage,]
legacy_comfortable=legacy_comfortable[legacy_comfortable$profilID%in%list_comfortable_coverage,]

Mario_basic=Mario[Mario$coverage=="Basic Coverage", ]
Mario_comfortable=Mario[Mario$coverage=="Comfortable Coverage", ]
Mario_basic=Mario_basic[Mario_basic$profilID%in%list_basic_coverage,]
Mario_comfortable=Mario_comfortable[Mario_comfortable$profilID%in%list_comfortable_coverage,]


legacy_PNO=legacy[legacy$coverage=="PNO", ]
Mario_PNO=Mario[Mario$coverage=="PNO", ]
## group competitors price with DA and BNP 

all=rbind(legacy_basic,legacy_comfortable, Mario_basic,Mario_comfortable, macif_pacifica2, macif_pacifica3, legacy_PNO, Mario_PNO)

all$formule_origine=matrix_HOME$formule_origine[match(all$profilID,matrix_HOME$profil_id)]

all[grepl("PNO",all$profilID),]$formule_origine=4

all=all[!all$insurer=="NO_INSURER",]

all=na.omit(all)

unique(all$formule_origine)
print(unique(all$period))
print(unique(all$insurer))
length(unique(all$profilID))


