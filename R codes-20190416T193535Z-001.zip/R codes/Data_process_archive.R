### update the prices of competitors with crawling data and prices of BNP and DA with calculation data by DA#################

#### crawling price 2015====

### loads the PostgreSQL driver
drv <- dbDriver("PostgreSQL")
#### Open a connection
con <- dbConnect(drv, dbname=db, host=dbHost, port=dbPort , user=dbUser, password=dbPassword)


matrix_HOME= dbGetQuery(con,  "select*
                        from business.\"legacy_matrix_HOME_FR\";")

### only the data of 2015 were avaiable in the data base:
ASSURLAND_HOME_Y15=  dbGetQuery(con,  "select *
                                from business.\"ASSURLAND_HOME_propals\" where \"campagneID\" like 'MRH2015%';")

ASSURLAND_HOME_1606=  dbGetQuery(con,  "select *
                                 from crawling.\"ASSURLAND_HOME_prices\" where \"campaignID\" like '%Y16M06_RECURRENT%';")

## Closes the connection
lapply(dbListConnections(drv), FUN = dbDisconnect)

## Frees all the resources on the driver
dbUnloadDriver(drv)

### crawling data 201606====
ASSURLAND_HOME_1606$yearmonth <- paste( "Y",substr(ASSURLAND_HOME_1606$year,3,4), "M",formatC(ASSURLAND_HOME_1606$month,width=2, flag="0") , sep = "")
table(ASSURLAND_HOME_1606$yearmonth)

## select only the useful variables
ASSURLAND_HOME_1606=subset(ASSURLAND_HOME_1606, select=c(profilID, insurer, coverage, prix, status,yearmonth))
colnames(ASSURLAND_HOME_1606)[4]="price"
summary(ASSURLAND_HOME_1606$price)
## remove the invalide price
ASSURLAND_HOME_1606=ASSURLAND_HOME_1606[!ASSURLAND_HOME_1606$price==0,]
summary(ASSURLAND_HOME_1606$price)
ASSURLAND_HOME_1606$formule_origine=matrix_HOME$formule_origine[match(ASSURLAND_HOME_1606$profilID,matrix_HOME$profil_id)]
ASSURLAND_HOME_1606$coverage=ifelse(ASSURLAND_HOME_1606$formule_origine=="2", "La formule Essentielle", "La formule Confort")
ASSURLAND_HOME_1606$insurer=as.character(ASSURLAND_HOME_1606$insurer)

tauxess=length(unique(ASSURLAND_HOME_1606[ASSURLAND_HOME_1606$coverage=="La formule Essentielle" ,]$profilID))/length(unique(ASSURLAND_HOME_1606$profilID))
tauxcon= length(unique(ASSURLAND_HOME_1606[ASSURLAND_HOME_1606$coverage=="La formule Confort" ,]$profilID))/length(unique(ASSURLAND_HOME_1606$profilID))

tauxess #42%
tauxcon #58%
ASSURLAND_HOME_1606=subset(ASSURLAND_HOME_1606, select=c(profilID,insurer,coverage,price,yearmonth))

#### crawling price in 201603====
ASSURLAND_HOME=read.csv2("./mapping_table/MRP/201603/mrh_mars_2016.csv",header=T,sep=";",dec=".")
### all insurer---> check if there are new insurer
all=c("MMA", "MAAF Assurances", "Groupe ASSU 2000","AcommeAssure", "Carrefour Assurances" ,"GMF" ,"NO_INSURER" )
ASSURLAND_HOME$insurer=as.character(ASSURLAND_HOME$insurer)
# check if there is a new competitor
newinsurer=unique(ASSURLAND_HOME$insurer)[!unique(ASSURLAND_HOME$insurer)%in%all]
newinsurer

## select only the matrix with profilID MRH201507
ASSURLAND_HOME=ASSURLAND_HOME[grepl("MRH201507", ASSURLAND_HOME$profilID),]

##799
ASSURLAND_HOME$yearmonth="Y16M03"
ASSURLAND_HOME$formule_origine=matrix_HOME$formule_origine[match(ASSURLAND_HOME$profilID,matrix_HOME$profil_id)]
ASSURLAND_HOME$coverage=ifelse(ASSURLAND_HOME$formule_origine=="2", "La formule Essentielle", "La formule Confort")
ASSURLAND_HOME$price=as.numeric(as.character(ASSURLAND_HOME$prix))

# crawling rate by coverages 

tauxess=length(unique(ASSURLAND_HOME[ASSURLAND_HOME$coverage=="La formule Essentielle" ,]$profilID))/length(unique(ASSURLAND_HOME$profilID))
tauxcon= length(unique(ASSURLAND_HOME[ASSURLAND_HOME$coverage=="La formule Confort" ,]$profilID))/length(unique(ASSURLAND_HOME$profilID))

tauxess #42%
tauxcon #58%

## remove non valided data
ASSURLAND_HOME=ASSURLAND_HOME[!ASSURLAND_HOME$price==0,]
ASSURLAND_HOME=ASSURLAND_HOME[!ASSURLAND_HOME$insurer=="NO_INSURER",]

## select the only useful variables
ASSURLAND_HOME=subset(ASSURLAND_HOME, select=c(profilID ,insurer,price,coverage,yearmonth))

#####data of 2015====
# define yearmonth variable 
ASSURLAND_HOME_Y15$yearmonth=strftime(as.Date(ASSURLAND_HOME_Y15$crawling_date,format="%Y-%m-%d"),format="Y%yM%m")

## remove the price =0 and insurer is no insurer
ASSURLAND_HOME_Y15=ASSURLAND_HOME_Y15[!ASSURLAND_HOME_Y15$price==0,]
ASSURLAND_HOME_Y15=ASSURLAND_HOME_Y15[!ASSURLAND_HOME_Y15$insurer=="NO_INSURER",]

## load table matrix (remove old matrix) only the new matrix
matrix_HOME=matrix_HOME[!matrix_HOME$dtobs=="28/02/2015",]
ASSURLAND_HOME_Y15=subset(ASSURLAND_HOME_Y15, select=c( profilID ,insurer,price,coverage,yearmonth))

## group crawling data 2016 and data 2015
ASSURLAND_HOME=rbind(ASSURLAND_HOME_Y15, ASSURLAND_HOME,ASSURLAND_HOME_1606)

##############DA price and BNP price====
### the price of DA and BNP were calculated by DA
### the price variables were decided by DA 

## 2015
DAMRH=read.csv("./mapping_table/MRP/201506/MRP_MRH_20150630_aller_retourDT2.csv", header=T,sep = ";")

### take DA price 
DAprice=price_extrat(DAMRH, "pttc_da_Eco_avecremise", "pttc_da_confort_sans_del_avecremise","Direct Assurance")

##take BNP price
Bnpprice=price_extrat_BNPeco(DAMRH, "pttc_bnp_Eco_remiseBNP", "pttc_confort_bnp_sans_DEL_remiseBNP","BNP Natio","equivalence_capital_eco")

## create the periods
crawl_period=c( "Y15M07", "Y15M11")

for(i in 1:length(crawl_period)){
  
  DAprice1=DAprice
  DAprice1$yearmonth =crawl_period[i]
  
  listess=unique(ASSURLAND_HOME[ASSURLAND_HOME$coverage=="La formule Essentielle"& ASSURLAND_HOME$yearmonth ==crawl_period[i],]$profilID)
  listconf=unique(ASSURLAND_HOME[ASSURLAND_HOME$coverage=="La formule Confort"& ASSURLAND_HOME$yearmonth ==crawl_period[i],]$profilID)
  length(listess)
  length(listconf)
  ## choose commun profils 
  DAprice1_ess=DAprice1[DAprice1$coverage=="La formule Essentielle", ]
  DAprice1_ess=DAprice1_ess[DAprice1_ess$profilID%in%listess,]
  ## choose commun profils 
  DAprice1_conf=DAprice1[DAprice1$coverage=="La formule Confort", ]
  DAprice1_conf=DAprice1_conf[DAprice1_conf$profilID%in%listconf,]
  DAprice2=rbind(DAprice1_ess,DAprice1_conf)
  
  rm(DAprice1)
  rm(DAprice1_ess)
  rm(DAprice1_conf)
  
  if (i==1) (DApricef=as.data.frame(DAprice2)) else DApricef=rbind(DApricef, DAprice2)
  
}

for(i in 1:length(crawl_period)){
  
  Bnpprice1=Bnpprice
  Bnpprice1$yearmonth =crawl_period[i]
  
  
  listess=unique(ASSURLAND_HOME[ASSURLAND_HOME$coverage=="La formule Essentielle"& ASSURLAND_HOME$yearmonth ==crawl_period[i],]$profilID)
  listconf=unique(ASSURLAND_HOME[ASSURLAND_HOME$coverage=="La formule Confort"& ASSURLAND_HOME$yearmonth ==crawl_period[i],]$profilID)
  length(listess)
  length(listconf)
  ## choose commun profils 
  Bnpprice1_ess=Bnpprice1[Bnpprice1$coverage=="La formule Essentielle", ]
  Bnpprice1_ess=Bnpprice1_ess[Bnpprice1_ess$profilID%in%listess,]
  ## choose commun profils 
  Bnpprice1_conf=Bnpprice1[Bnpprice1$coverage=="La formule Confort", ]
  Bnpprice1_conf=Bnpprice1_conf[Bnpprice1_conf$profilID%in%listconf,]
  Bnpprice2=rbind(Bnpprice1_ess,Bnpprice1_conf)
  
  rm(Bnpprice1)
  rm(Bnpprice1_ess)
  rm(Bnpprice1_conf)
  
  
  if (i==1) (Bnppricef=as.data.frame(Bnpprice2)) else Bnppricef=rbind(Bnppricef, Bnpprice2)
  Bnppricef=na.omit(Bnppricef)
}

#### new price in 201603
### new price from DA
New_price=read.csv2("./mapping_table/MRP/201603/MRH_Matrix_201603.csv",header=T,sep=";",dec=".")
### take DA price 
DAprice_16=price_extrat(New_price, "pttc_da_Eco", "pttc_da_confort_sans_del","Direct Assurance")
##BNP price
BNPprice_16=price_extrat(New_price, "pttc_bnp_Eco", "pttc_confort_bnp_sans_DEL","BNP Natio")

## creat period for DA and BNP; selection commun profils

crawl_period1=c("Y16M03","Y16M06")
crawl_period11=c("Y16M03")

for(i in 1:length(crawl_period1)){
  
  DAprice_161=DAprice_16
  DAprice_161$yearmonth =crawl_period1[i]
  
  listess=unique(ASSURLAND_HOME[ASSURLAND_HOME$coverage=="La formule Essentielle"& ASSURLAND_HOME$yearmonth ==crawl_period1[i],]$profilID)
  listconf=unique(ASSURLAND_HOME[ASSURLAND_HOME$coverage=="La formule Confort"& ASSURLAND_HOME$yearmonth ==crawl_period1[i],]$profilID)
  length(listess)
  length(listconf)
  ## choose commun profils 
  DAprice_161_ess=DAprice_161[DAprice_161$coverage=="La formule Essentielle", ]
  DAprice_161_ess=DAprice_161_ess[DAprice_161_ess$profilID%in%listess,]
  ## choose commun profils 
  DAprice_161_conf=DAprice_161[DAprice_161$coverage=="La formule Confort", ]
  DAprice_161_conf=DAprice_161_conf[DAprice_161_conf$profilID%in%listconf,]
  DAprice_162=rbind(DAprice_161_ess,DAprice_161_conf)
  
  rm(DAprice_161)
  rm(DAprice_161_ess)
  rm(DAprice_161_conf)
  
  if (i==1) (DAprice_16f=as.data.frame(DAprice_162)) else DAprice_16f=rbind(DAprice_16f, DAprice_162)
  
}

for(i in 1:length(crawl_period11)){
  
  Bnpprice_161=BNPprice_16
  Bnpprice_161$yearmonth =crawl_period11[i]
  
  
  listess=unique(ASSURLAND_HOME[ASSURLAND_HOME$coverage=="La formule Essentielle"& ASSURLAND_HOME$yearmonth ==crawl_period11[i],]$profilID)
  listconf=unique(ASSURLAND_HOME[ASSURLAND_HOME$coverage=="La formule Confort"& ASSURLAND_HOME$yearmonth ==crawl_period11[i],]$profilID)
  length(listess)
  length(listconf)
  ## choose commun profils 
  Bnpprice_161_ess=Bnpprice_161[Bnpprice_161$coverage=="La formule Essentielle", ]
  Bnpprice_161_ess=Bnpprice_161_ess[Bnpprice_161_ess$profilID%in%listess,]
  ## choose commun profils 
  Bnpprice_161_conf=Bnpprice_161[Bnpprice_161$coverage=="La formule Confort", ]
  Bnpprice_161_conf=Bnpprice_161_conf[Bnpprice_161_conf$profilID%in%listconf,]
  Bnpprice_162=rbind(Bnpprice_161_ess,Bnpprice_161_conf)
  
  rm(Bnpprice_161)
  rm(Bnpprice_161_ess)
  rm(Bnpprice_161_conf)
  
  
  if (i==1) (Bnpprice_16f=as.data.frame(Bnpprice_162)) else Bnpprice_16f=rbind(Bnpprice_16f, Bnpprice_162)
  Bnpprice_16f=na.omit(Bnpprice_16f)
}

#############################201606
### new tarrif for BNP
New_price_06=read.csv2("./mapping_table/MRP/201606/MRH_Matrix_201603newbnp.csv",header=T,sep=";",dec=".")
New_price_06$PTTC_TOTAL_BNP_ECO=as.numeric(gsub(",", ".", gsub("\\.", "", New_price_06$PTTC_TOTAL_BNP_ECO)))
New_price_06$PTTC_TOTAL_BNP_CONF=as.numeric(gsub(",", ".", gsub("\\.", "", New_price_06$PTTC_TOTAL_BNP_CONF)))

## DA price: the same as in 201603

##BNP price
Bnpprice_16f06=price_extrat(New_price_06, "PTTC_TOTAL_BNP_ECO", "PTTC_TOTAL_BNP_CONF","BNP Natio")
summary(Bnpprice_16f06$price)

### bnp
crawl_period_bnp="Y16M06"

for(i in 1:length(crawl_period1)){
  
  Bnppric_16e061=Bnpprice_16f06
  Bnppric_16e061$yearmonth =crawl_period_bnp
  
  
  listess=unique(ASSURLAND_HOME[ASSURLAND_HOME$coverage=="La formule Essentielle"& ASSURLAND_HOME$yearmonth ==crawl_period1[i],]$profilID)
  listconf=unique(ASSURLAND_HOME[ASSURLAND_HOME$coverage=="La formule Confort"& ASSURLAND_HOME$yearmonth ==crawl_period1[i],]$profilID)
  length(listess)
  length(listconf)
  ## choose commun profils 
  Bnpprice_161_ess06=Bnppric_16e061[Bnppric_16e061$coverage=="La formule Essentielle", ]
  Bnpprice_161_ess06=Bnpprice_161_ess06[Bnpprice_161_ess06$profilID%in%listess,]
  ## choose commun profils 
  Bnpprice_161_conf06=Bnppric_16e061[Bnppric_16e061$coverage=="La formule Confort", ]
  Bnpprice_161_conf06=Bnpprice_161_conf06[Bnpprice_161_conf06$profilID%in%listconf,]
  
  Bnpprice_16206=rbind(Bnpprice_161_ess06,Bnpprice_161_conf06)
  
  if (i==1) (Bnpprice_16f06final=as.data.frame(Bnpprice_16206)) else Bnpprice_16f06final=rbind(Bnpprice_16f06final, Bnpprice_16206)
  Bnpprice_16f06final=na.omit(Bnpprice_16f06final)
}


### group BNP + others 

Bnppricef=subset(Bnppricef, select=c(profilID,insurer,coverage, price , yearmonth))

Bnpprice_16f=subset(Bnpprice_16f, select=c(profilID,insurer,coverage, price , yearmonth))

Bnpprice_16f06final=subset(Bnpprice_16f06final, select=c(profilID,insurer,coverage, price , yearmonth))

### group all DA prices 

DApricef=subset(DApricef, select=c(profilID,insurer,coverage, price , yearmonth))
DAprice_16f=subset(DAprice_16f, select=c(profilID,insurer,coverage, price , yearmonth))

### group all the  prices
ASSURLAND_HOME_DA_BNP=rbind(DApricef,DAprice_16f,ASSURLAND_HOME,Bnppricef,Bnpprice_16f, Bnpprice_16f06final)
ASSURLAND_HOME_DA_BNP=unique(ASSURLAND_HOME_DA_BNP)
ASSURLAND_HOME_DA_BNP$period=ASSURLAND_HOME_DA_BNP$yearmonth

## change coverage names 

ASSURLAND_HOME_DA_BNP$coverage1=ifelse(ASSURLAND_HOME_DA_BNP$coverage=="La formule Essentielle","Basic Coverage", ifelse(ASSURLAND_HOME_DA_BNP$coverage=="La formule Confort","Comfortable Coverage",""))
ASSURLAND_HOME_DA_BNP=subset(ASSURLAND_HOME_DA_BNP,select=c(profilID,insurer,coverage1,price,yearmonth,period))
names(ASSURLAND_HOME_DA_BNP)=c("profilID","insurer","coverage","price","yearmonth","period")

## save this final table

save(ASSURLAND_HOME_DA_BNP, file = "./Output_MRH/ASSURLAND_HOME_DA_BNP.RData")

