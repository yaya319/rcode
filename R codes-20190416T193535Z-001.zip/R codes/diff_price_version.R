
## comparer different version tarif

# V59 tarfi current

v59=read.csv2("./mapping_table/MRP/201609/DA_tarifv59.csv",header=T,sep=";",dec=".")
v59=subset(v59, select=c(CNT_ID, pttc_da_Eco,pttc_da_confort_sans_del ))
names(v59)=c("CNT_ID", "Economique", "Confort")
v59 <- melt(v59, id=c("CNT_ID"))
names(v59)=c( "idcnt" , "Formula", "price")
## var V59 vs Mario

mario_newproductF2=read.csv2("./mapping_table/MRP/201609/Mario/tarif_Mario_light20160914_F2.csv",header=T,sep=";",dec=".")
mario_newproductF2=mario_newproductF2[mario_newproductF2$Formula=="Economique",]
mario_newproductF2$var= (mario_newproductF2$pttc_ho_tot_leg /mario_newproductF2$pttc_ho_v59)-1
summary(mario_newproductF2$var)

mario_newproductF3=read.csv2("./mapping_table/MRP/201609/Mario/tarif_Mario_light20160914_F3.csv",header=T,sep=";",dec=".")
mario_newproductF3=mario_newproductF3[mario_newproductF3$Formula=="Confort",]
mario_newproductF3$var= (mario_newproductF3$pttc_ho_tot_leg /mario_newproductF3$pttc_ho_v59)-1
summary(mario_newproductF3$var)


mario_newproduct=rbind(mario_newproductF2, mario_newproductF3 )

all_v59=merge(v59,mario_newproduct, by=c("idcnt","Formula" ))

## var V59 vs V59 essentiel
all_v59$var_v59=all_v59$pttc_ho_v59/all_v59$price-1
all_v59$var_v59


## the price difference between V59 and Mario

#mario
data=mario_newproduct

data$mario_v59=(data$pttc_o_tot_leg/data$pttc_ho_v59)-1

data$mario_v59=round(data$mario_v59*100,2)

summary(data$mario_v59)

test=data[data$mario_v59>100,]
test=subset(test, select=c(pttc_o_tot_leg, pttc_ho_v59))

## PP_CAT_AGPC NA --> ????
cov=unique(data$Formula)
histogram_break=20

for (i in 1:length(cov)){
  
  data1=data[data$Formula==cov[i], ]

   summary(data1$mario_v59)

   p1rctrd1=density(x=na.omit(data1$mario_v59),bw="sj")

  h<-hist(data1$mario_v59) 

png(filename=paste(PathNameevol,paste("DA",unique(data1$Formule), "Price differences.png",sep="_"),sep="/"),width = 760, height = 700);

h<-hist(data1$mario_v59,freq=FALSE, breaks=histogram_break, col="lightgreen",ylim=c(0, .50),main="",xlab="")
lines(p1rctrd1,col="darkblue",lwd = 2,main="")
title(paste("Price Changes Distribution",paste("DA",unique(data1$Formule),sep=" / "),sep="\n"),cex.main =2) 

dev.off ();
}

## summary by options 
meanna=function(x){
  return(mean(x, na.rm=T))
}


verify<- data.table(mario_newproduct)

names=names(verify)[grepl("pp|pch|pttc",names(verify))]


## find prime pure 
names(mario_newproduct)[grepl("pp_ho",names(mario_newproduct)) & !grepl("v59",names(mario_newproduct))]
names(mario_newproduct)[grepl("pp_ho",names(mario_newproduct))]
names(mario_newproduct)[grepl("Mario",names(mario_newproduct)) &grepl("pp_ho",names(mario_newproduct)) & !grepl("v59",names(mario_newproduct))]

## prime pure
verify_table=data.frame(option=c("WD","FEI","TAV","TPL","SWD","WGB","WID AGPC","WID","LA","ASS"), v59_ho=0, Mario=0)

verify_table[verify_table$option=="WD",]$Mario = meanna(mario_newproduct$pp_ho_WD)
verify_table[verify_table$option=="FEI",]$Mario = meanna(mario_newproduct$pp_ho_FEI)
verify_table[verify_table$option=="TAV",]$Mario = meanna(mario_newproduct$pp_ho_TAV)
verify_table[verify_table$option=="TPL",]$Mario = meanna(mario_newproduct$pp_ho_TPL)
verify_table[verify_table$option=="SWD",]$Mario = meanna(mario_newproduct$pp_ho_SWD)
verify_table[verify_table$option=="WGB",]$Mario = meanna(mario_newproduct$pp_ho_WGB)
verify_table[verify_table$option=="WID",]$Mario = meanna(mario_newproduct$pp_ho_WID_leg)
verify_table[verify_table$option=="LA",]$Mario = meanna(mario_newproduct$pp_ho_LA)
verify_table[verify_table$option=="ASS",]$Mario = meanna(mario_newproduct$pp_ho_ASS)

verify_table[verify_table$option=="WD",]$v59_ho = meanna(mario_newproduct$pp_ho_WD_v59) 
verify_table[verify_table$option=="FEI",]$v59_ho = meanna(mario_newproduct$pp_ho_FEI_v59)
verify_table[verify_table$option=="TAV",]$v59_ho = meanna(mario_newproduct$pp_ho_TAV_v59)
verify_table[verify_table$option=="TPL",]$v59_ho = meanna(mario_newproduct$pp_ho_TPL_v59)
verify_table[verify_table$option=="SWD",]$v59_ho = meanna(mario_newproduct$pp_ho_SWD_v59)
verify_table[verify_table$option=="WGB",]$v59_ho = meanna(mario_newproduct$pp_ho_WGB_v59)
verify_table[verify_table$option=="WID",]$v59_ho = meanna(mario_newproduct$pp_ho_WID_v59)
verify_table[verify_table$option=="LA",]$v59_ho = meanna(mario_newproduct$pp_ho_LA_v59)
verify_table[verify_table$option=="ASS",]$v59_ho = meanna(mario_newproduct$pp_ho_ASS_v59)

## chargement 
names(mario_newproduct)[grepl("pch",names(mario_newproduct))]


## prime pure
verify_table_ch=data.frame(option=c("WD","FEI","TAV","TPL","SWD","WGB","WID AGPC","WID","LA","ASS"), v59_ho=0, Mario=0)

verify_table_ch[verify_table_ch$option=="WD",]$Mario = meanna(mario_newproduct$pcht_ho_WD)
verify_table_ch[verify_table_ch$option=="FEI",]$Mario = meanna(mario_newproduct$pcht_ho_FEI)
verify_table_ch[verify_table_ch$option=="TAV",]$Mario = meanna(mario_newproduct$pcht_ho_TAV)
verify_table_ch[verify_table_ch$option=="TPL",]$Mario = meanna(mario_newproduct$pcht_ho_TPL)
verify_table_ch[verify_table_ch$option=="SWD",]$Mario = meanna(mario_newproduct$pcht_ho_SWD)
verify_table_ch[verify_table_ch$option=="WGB",]$Mario = meanna(mario_newproduct$pcht_ho_WGB)
verify_table_ch[verify_table_ch$option=="WID",]$Mario = meanna(mario_newproduct$pcht_ho_WID_leg)
verify_table_ch[verify_table_ch$option=="LA",]$Mario = meanna(mario_newproduct$pcht_ho_LA)
verify_table_ch[verify_table_ch$option=="ASS",]$Mario = meanna(mario_newproduct$pcht_ho_ASS)

verify_table_ch[verify_table_ch$option=="WD",]$v59_ho = meanna(mario_newproduct$pcht_ho_WD_v59) 
verify_table_ch[verify_table_ch$option=="FEI",]$v59_ho = meanna(mario_newproduct$pcht_ho_FEI_v59)
verify_table_ch[verify_table_ch$option=="TAV",]$v59_ho = meanna(mario_newproduct$pcht_ho_TAV_v59)
verify_table_ch[verify_table_ch$option=="TPL",]$v59_ho = meanna(mario_newproduct$pcht_ho_TPL_v59)
verify_table_ch[verify_table_ch$option=="SWD",]$v59_ho = meanna(mario_newproduct$pcht_ho_SWD_v59)
verify_table_ch[verify_table_ch$option=="WGB",]$v59_ho = meanna(mario_newproduct$pcht_ho_WGB_v59)
verify_table_ch[verify_table_ch$option=="WID",]$v59_ho = meanna(mario_newproduct$pcht_ho_WID_v59)
verify_table_ch[verify_table_ch$option=="LA",]$v59_ho = meanna(mario_newproduct$pcht_ho_LA_v59)
verify_table_ch[verify_table_ch$option=="ASS",]$v59_ho = meanna(mario_newproduct$pcht_ho_ASS_v59)


## ttc
verify_table_ttc=data.frame(option=c("WD","FEI","TAV","TPL","SWD","WGB","WID AGPC","WID","LA","ASS"), v59_ho=0, Mario=0)

verify_table_ttc[verify_table_ttc$option=="WD",]$Mario = meanna(mario_newproduct$pttc_ho_WD)
verify_table_ttc[verify_table_ttc$option=="FEI",]$Mario = meanna(mario_newproduct$pttc_ho_FEI)
verify_table_ttc[verify_table_ttc$option=="TAV",]$Mario = meanna(mario_newproduct$pttc_ho_TAV)
verify_table_ttc[verify_table_ttc$option=="TPL",]$Mario = meanna(mario_newproduct$pttc_ho_TPL)
verify_table_ttc[verify_table_ttc$option=="SWD",]$Mario = meanna(mario_newproduct$pttc_ho_SWD)
verify_table_ttc[verify_table_ttc$option=="WGB",]$Mario = meanna(mario_newproduct$pttc_ho_WGB)
verify_table_ttc[verify_table_ttc$option=="WID",]$Mario = meanna(mario_newproduct$pttc_ho_WID_leg)
verify_table_ttc[verify_table_ttc$option=="LA",]$Mario = meanna(mario_newproduct$pttc_ho_LA)
verify_table_ttc[verify_table_ttc$option=="ASS",]$Mario = meanna(mario_newproduct$pttc_ho_ASS)

verify_table_ttc[verify_table_ttc$option=="WD",]$v59_ho = meanna(mario_newproduct$pttc_ho_WD_v59) 
verify_table_ttc[verify_table_ttc$option=="FEI",]$v59_ho = meanna(mario_newproduct$pttc_ho_FEI_v59)
verify_table_ttc[verify_table_ttc$option=="TAV",]$v59_ho = meanna(mario_newproduct$pttc_ho_TAV_v59)
verify_table_ttc[verify_table_ttc$option=="TPL",]$v59_ho = meanna(mario_newproduct$pttc_ho_TPL_v59)
verify_table_ttc[verify_table_ttc$option=="SWD",]$v59_ho = meanna(mario_newproduct$pttc_ho_SWD_v59)
verify_table_ttc[verify_table_ttc$option=="WGB",]$v59_ho = meanna(mario_newproduct$pttc_ho_WGB_v59)
verify_table_ttc[verify_table_ttc$option=="WID",]$v59_ho = meanna(mario_newproduct$pttc_ho_WID_v59)
verify_table_ttc[verify_table_ttc$option=="LA",]$v59_ho = meanna(mario_newproduct$pttc_ho_LA_v59)
verify_table_ttc[verify_table_ttc$option=="ASS",]$v59_ho = meanna(mario_newproduct$pttc_ho_ASS_v59)



verify_table_tot=data.frame(version=c("v59_ho", "Mario_ho"), prime_pure=0, prime_charge=0, prime_ttc=0)
verify_table_tot=data.table(verify_table_tot)
verify_table_tot[verify_table_tot$version=="v59_ho",]$prime_pure=meanna(mario_newproduct$pp_ho_v59)
verify_table_tot[verify_table_tot$version=="v59_ho",]$prime_charge=meanna(mario_newproduct$pcht_ho_v59)
verify_table_tot[verify_table_tot$version=="v59_ho",]$prime_ttc=meanna(mario_newproduct$pttc_ho_v59)

verify_table_tot[verify_table_tot$version=="Mario_ho",]$prime_pure=meanna(mario_newproduct$pp_ho_tot_leg)
verify_table_tot[verify_table_tot$version=="Mario_ho",]$prime_charge=meanna(mario_newproduct$pch_ho_tot_leg)
verify_table_tot[verify_table_tot$version=="Mario_ho",]$prime_ttc=meanna(mario_newproduct$pttc_ho_tot_leg)

verify_table_tot$charge=as.numeric(verify_table_tot$prime_charge)-as.numeric(verify_table_tot$prime_pure)

library(rJava)
library(xlsxjars)
library(xlsx)

## add different table to excel 
wb<-createWorkbook(type="xlsx")
sheet <-createSheet(wb, sheetName = "test")
# Ajouter une table
addDataFrame(verify_table, sheet, startRow=3, startColumn=1)
addDataFrame(verify_table_ch, sheet, startRow=18, startColumn=1)
addDataFrame(verify_table_ttc, sheet, startRow=32, startColumn=1)
addDataFrame(verify_table_tot, sheet, startRow=47, startColumn=1)

saveWorkbook(wb, "verify.xlsx")
