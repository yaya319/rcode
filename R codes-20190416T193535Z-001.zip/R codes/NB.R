######## data preparation for NB#####################################

## DA price NB
DA_NB=read.csv2("./mapping_table/NB/AN_MarioV11GCPREC4.csv",header=T,sep=";",dec=".")

DA_NB=subset(DA_NB, select=c(CNT_ID,   RoomsBeyond40m2  ,RoomsBelow40m2,TotalSurface,ResidenceType,Floor, OccupantType,HomeType,DepartementCode,  RegionCode,  
                             insee ,multiriskzone_da2015, ContentValue ,Formula ,PolicyHolderAge, pttc_ho_v58, pttc_ho_tot_leg_att))

########################## test#################

##mapping for hometype 
DA_NB$home=ifelse(DA_NB$HomeType%in%c(1,5,6,7,8,9),"Flat",ifelse(DA_NB$HomeType%in%c(2,3,4),"House", ""))
table(DA_NB$home)

##mapping for occupant type
DA_NB$occ=ifelse(DA_NB$OccupantType==1,"Owner",ifelse(DA_NB$OccupantType==2,"Tenant", 
                                                                     ifelse(DA_NB$OccupantType==3,"Tenant", ifelse(DA_NB$OccupantType==4,"PNO",""))))
table(DA_NB$occ)
DA_NB$occ_home=paste(DA_NB$home, DA_NB$occ)
DA_NB=na.omit(DA_NB)
DA_NB_summary=data.table(DA_NB)
DA_NB_summary <- DA_NB_summary[,list(mean=mean(pttc_ho_v58)), by = c("occ_home")]

DA_NB_summary1=data.table(DA_NB)
DA_NB_summary1 <- DA_NB_summary1[,list(mean=mean(pttc_ho_tot_leg_att)), by = c("occ_home")]


DA_NB$occ_home=paste(DA_NB$HomeType, DA_NB$OccupantType)
########################################################################
table(DA_NB$DepartementCode)   
table(DA_NB$RegionCode)   
table(DA_NB$Formula)
length(unique(DA_NB$CNT_ID))

DA_NB$coverage=ifelse(DA_NB$Formula==2, "Basic Coverage",ifelse(DA_NB$Formula==3, "Comfortable Coverage",ifelse(DA_NB$Formula==4, 
                                                                                                                "Comfortable Plus Coverage", ifelse(DA_NB$Formula==5, "PNO","NA"))))

table(DA_NB$coverage)                               

## profiles liste by coverage to keep the same for competitors 

# basic coverage
NB_basic_profil=unique(DA_NB[DA_NB$coverage=="Basic Coverage",]$CNT_ID)
# comfortable 
NB_comfortable_profil=unique(DA_NB[DA_NB$coverage=="Comfortable Coverage",]$CNT_ID)
# PNO
NB_PNO_profil=unique(DA_NB[DA_NB$coverage=="PNO",]$CNT_ID)

directassurance=data.frame("profilID"=DA_NB$CNT_ID, "price"=DA_NB$pttc_ho_tot_leg_att, "coverage"=DA_NB$coverage, "insurer"="Direct Assurance")

directassurance_legacy=data.frame("profilID"=DA_NB$CNT_ID, "price"=DA_NB$pttc_ho_v58, "coverage"=DA_NB$coverage, "insurer"="Direct Assurance")

##Macif

macif_appart_NB=read.csv2("Z:/Users/Y.LI/Bechmarks/Reverse/Macif/MACIF_APARTMENT/macif_price_appart_NB.csv",header=T,sep=";",dec=".")
macif_house_NB=read.csv2("Z:/Users/Y.LI/Bechmarks/Reverse/Macif/MACIF_HOUSE/macif_house_price_NB.csv",header=T,sep=";",dec=".")
macif_ess_appart_NB=read.csv2("Z:/Users/Y.LI/Bechmarks/Reverse/Macif/MACIF_APARTMENT/macif_price_ess_appart_NB.csv",header=T,sep=";",dec=".")

macif_appart_NB1=macif_data(macif_appart_NB)
macif_house_NB1=macif_data(macif_house_NB)

macif_NB=rbind(macif_house_NB1, macif_appart_NB1)
macif_NB$coverage="Comfortable Coverage"
macif_NB$insurer="Macif"
macif_NB_com=macif_NB[macif_NB$profilID%in%NB_comfortable_profil,]

## select the coverage comfortable for PNO price

macif_NB_pno=macif_NB[macif_NB$profilID%in%NB_PNO_profil, ]
macif_NB_pno$coverage="PNO"

## basic
macif_ess_appart_NB1=macif_data(macif_ess_appart_NB)
macif_ess_appart_NB1$coverage="Basic Coverage"
macif_ess_appart_NB1$insurer="Macif"
macif_ess_appart_NB1=macif_ess_appart_NB1[macif_ess_appart_NB1$profilID%in%NB_basic_profil,]
## group three coverages
macif_NB=rbind(macif_NB_com, macif_ess_appart_NB1, macif_NB_pno)
macif_NB=macif_NB[!macif_NB$price==0,]

length(unique(macif_NB[macif_NB$coverage=="Basic Coverage",]$profilID))
length(unique(macif_NB[macif_NB$coverage=="Comfortable Coverage",]$profilID))
length(unique(macif_NB[macif_NB$coverage=="PNO",]$profilID))

summary(macif_NB[macif_NB$coverage=="Basic Coverage",]$price)
summary(macif_NB[macif_NB$coverage=="Comfortable Coverage",]$price)
summary(macif_NB[macif_NB$coverage=="PNO",]$price)

## Pacifca
## pacifica price
pacifica_house_NB=read.csv2("Z:/Users/Y.LI/Bechmarks/Reverse/Pacifica/House/pacifica_house_price_NB.csv",header=T,sep=";",dec=".")
pacifica_house_NB=subset(pacifica_house_NB, select=c( Profile.No.,Initial,   Integral))
pacifica_appart_NB=read.csv2("Z:/Users/Y.LI/Bechmarks/Reverse/Pacifica/Apartement/pacifica_appart_price_NB.csv",header=T,sep=";",dec=".")
pacifica_appart_NB=subset(pacifica_appart_NB, select=c( Profile.No.,Initial,   Integral))

pacifica_NB=rbind(pacifica_house_NB, pacifica_appart_NB)

pacifica_NB1=pacifica_data(pacifica_NB)

pacifica_NB1_b=pacifica_NB1[pacifica_NB1$coverage=="Basic Coverage",]
pacifica_NB1_c=pacifica_NB1[pacifica_NB1$coverage=="Comfortable Coverage",]

pacifica_NB1_b= pacifica_NB1_b[pacifica_NB1_b$profilID%in%NB_basic_profil,]
pacifica_NB1_c= pacifica_NB1_c[pacifica_NB1_c$profilID%in%NB_comfortable_profil,]

## select the coverage comfortable for PNO price
pacifica_NB1_pno=pacifica_NB1[pacifica_NB1$coverage=="Comfortable Coverage",]
pacifica_NB1_pno=pacifica_NB1_pno[pacifica_NB1_pno$profilID%in%NB_PNO_profil, ]
pacifica_NB1_pno$coverage="PNO"

pacifica_NB1_con=rbind(pacifica_NB1_b, pacifica_NB1_c, pacifica_NB1_pno )

summary(pacifica_NB1_con[pacifica_NB1_con$coverage=="Basic Coverage",]$price)
summary(pacifica_NB1_con[pacifica_NB1_con$coverage=="Comfortable Coverage",]$price)

length(unique(pacifica_NB1_con[pacifica_NB1_con$coverage=="Basic Coverage",]$profilID))
length(unique(pacifica_NB1_con[pacifica_NB1_con$coverage=="Comfortable Coverage",]$profilID))
length(unique(pacifica_NB1_con[pacifica_NB1_con$coverage=="PNO",]$profilID))

##
NB_two=rbind(macif_NB, pacifica_NB1_con)
two_ess=unique(NB_two[NB_two$coverage=="Basic Coverage",]$profilID)
two_com=unique(NB_two[NB_two$coverage=="Comfortable Coverage",]$profilID)
two_pno=unique(NB_two[NB_two$coverage=="PNO",]$profilID)

NB_two$period="Y16M09"
NB_two_bis=NB_two
NB_two_bis$period="Y16M09_Mario"

#mario               
directassurance_ess=directassurance[directassurance$coverage=="Basic Coverage",]
directassurance_ess=directassurance_ess[directassurance_ess$profilID%in%two_ess,  ]
directassurance_ess=na.omit(directassurance_ess)

directassurance_com=directassurance[directassurance$coverage=="Comfortable Coverage",]
directassurance_com=directassurance_com[directassurance_com$profilID%in%two_com,  ]
directassurance_com=na.omit(directassurance_com)

directassurance_pno=directassurance[directassurance$coverage=="PNO",]
directassurance_pno=directassurance_pno[directassurance_pno$profilID%in%two_pno,  ]
directassurance_pno=na.omit(directassurance_pno)

directassuranc_res=rbind(directassurance_ess,directassurance_com, directassurance_pno )

directassuranc_res$period="Y16M09_Mario"

## leagacy 

directassurance_legacy_ess=directassurance_legacy[directassurance_legacy$coverage=="Basic Coverage",]
directassurance_legacy_ess=directassurance_legacy_ess[directassurance_legacy_ess$profilID%in%two_ess,  ]
directassurance_legacy_ess=na.omit(directassurance_legacy_ess)

directassurance_legacy_com=directassurance_legacy[directassurance_legacy$coverage=="Comfortable Coverage",]
directassurance_legacy_com=directassurance_legacy_com[directassurance_legacy_com$profilID%in%two_com,  ]
directassurance_legacy_com=na.omit(directassurance_legacy_com)

directassurance_legacy_pno=directassurance_legacy[directassurance_legacy$coverage=="PNO",]
directassurance_legacy_pno=directassurance_legacy_pno[directassurance_legacy_pno$profilID%in%two_pno,  ]
directassurance_legacy_pno=na.omit(directassurance_legacy_pno)

directassurance_legacy_res=rbind(directassurance_legacy_pno,directassurance_legacy_com, directassurance_legacy_ess )

directassurance_legacy_res$period="Y16M09"
## group all
NB_three=rbind(NB_two, NB_two_bis, directassurance_legacy_res, directassuranc_res)

NB_three=unique(NB_three)

NB_three_summary=data.table(NB_three)
NB_three_summary <- NB_three_summary[,list(mean=mean(price)), by = c("coverage","period","insurer")]

write.table(NB_three_summary, file=paste(PathNamerank,"NB_three_summary.csv",sep="/"), col.names=TRUE,row.names=FALSE,sep=";",quote=FALSE)

NB_three_profil=data.table(NB_three)
NB_three_profil$ct=1
NB_three_summaryprofil <- NB_three_profil[,list(somme=sum(ct)), by = c("coverage","period","insurer")]
write.table(NB_three_summaryprofil, file=paste(PathNamerank,"NB_three_summary.csv",sep="/"), col.names=TRUE,row.names=FALSE,sep=";",quote=FALSE)


############################################## top 1 ranking analyses######################################

covfr=c("Basic Coverage" ,"Comfortable Coverage", "PNO")
coveragenames=c("Basic Coverage" ,"Comfortable Coverage", "PNO")

month=c("Y16M09" ,  "Y16M09_Mario" )

player=c("Macif", "Pacifica" , "Direct Assurance" )
## the name for outputs
Name="Direct Assurance NB"

## top 1 ranking
## find top 1 rank with function top1propor
NB_three_top1=top1propor(NB_three)
## calculate proportion
NB_three_top1$proportion=NB_three_top1$cumsum/NB_three_top1$cumsum2
NB_three_top1$proportion=round(NB_three_top1$proportion*100)

## output graphs
top1all(NB_three_top1, covfr, Name, coveragenames)


NB_three_global_summary=data.table(NB_three)
NB_three_global_summary <- NB_three_global_summary[,list(mean=mean(price)), by = c("period","coverage","insurer")]

write.table(NB_three_global_summary, file=paste(PathNameseg,"NB_three_global_summary.csv",sep="/"), col.names=TRUE,row.names=FALSE,sep=";",quote=FALSE)

####### ranking by segments######################

## take only matrix in 201507: this was loaded in the data prepartion step
matrix_HOME_NB=DA_NB

################ owner * house type#####################

## find the hometype and occupant type for each profile 
NB_three$hometype=matrix_HOME_NB$HomeType[match(NB_three$profilID,matrix_HOME_NB$CNT_ID)]

table(NB_three$hometype)

NB_three$occupanttype=matrix_HOME_NB$OccupantType[match(NB_three$profilID,matrix_HOME_NB$CNT_ID)]
table(NB_three$occupanttype)

##mapping for hometype 
NB_three$hometype=ifelse(NB_three$hometype%in%c(1,5,6,7,8,9),"Flat",ifelse(NB_three$hometype%in%c(2,3,4),"House", ""))
table(NB_three$hometype)

##mapping for occupant type
NB_three$occupanttype=ifelse(NB_three$occupanttype==1,"Owner",ifelse(NB_three$occupanttype==2,"Tenant", 
                             ifelse(NB_three$occupanttype==3,"Tenant", ifelse(NB_three$occupanttype==4,"PNO",""))))
table(NB_three$occupanttype)

## creat segment home type * occupant type
NB_three$occupanttype_hometype=paste(NB_three$occupanttype,NB_three$hometype)
unique(NB_three$occupanttype_hometype)

## keep only useful varaiables
NB_three_occupanttype_hometype=subset(NB_three,select=c(profilID, insurer,period,coverage,price,occupanttype_hometype))
## renames all the variables
names(NB_three_occupanttype_hometype)=c("profilID", "insurer","period","coverage","price","segment")

## find the top1 profile by segment
NB_three_occupanttype_hometype_top1=top1propor_segment(NB_three_occupanttype_hometype)

## calculate the top1 proportion
NB_three_occupanttype_hometype_top1$proportion=round((NB_three_occupanttype_hometype_top1$cumsum/NB_three_occupanttype_hometype_top1$cumsum2)*100)

## calculate profile number by each segment
profil_number_home_occ=data.table(NB_three_occupanttype_hometype)
profil_number_home_occ$ct=1
profil_number_home_occ <- profil_number_home_occ[,list(somme=sum(ct)), by = c("period","coverage","insurer","segment")]
write.table(profil_number_home_occ, file=paste(PathNameseg,"profil_number_home_occ.csv",sep="/"), col.names=TRUE,row.names=FALSE,sep=";",quote=FALSE)

NB_three_occupanttype_hometype_summary=data.table(NB_three_occupanttype_hometype)
NB_three_occupanttype_hometype_summary <- NB_three_occupanttype_hometype_summary[,list(mean=mean(price)), by = c("period","coverage","insurer","segment")]

write.table(NB_three_occupanttype_hometype_summary, file=paste(PathNameseg,"NB_three_summary_all.csv",sep="/"), col.names=TRUE,row.names=FALSE,sep=";",quote=FALSE)

## outptu the graphs 
rankseg_output_segment(NB_three_occupanttype_hometype_top1, paste("occupanttype_hometype", "NB"),PathNameseg)


############################## region################################

######### find the region and city name for each profile 
NB_three$RegionCode=matrix_HOME_NB$RegionCode[match(NB_three$profilID,matrix_HOME_NB$CNT_ID)]

table(NB_three$RegionCode)

NB_three$region=ifelse(NB_three$RegionCode%in%c(59,62,2,60,80,14,50,61,27,76),"D.R. LILLE", 
                       ifelse(NB_three$RegionCode%in%c(22,29,35,56,44,49,53,72,85,18,28,36,37,41,45),"D.R. NANTES",
                              ifelse(NB_three$RegionCode%in%c(16,17,79,86,19,23,87,24,33,40,47,64,9,12,31,32,46,65,81,82), "D.R. BORDEAUX",
                                     ifelse(NB_three$RegionCode%in%c(11,30,34,48,66,4,5,6,13001-13016,13,83,84), "D.R. MARSEILLE", 
                                       ifelse(NB_three$RegionCode%in%c(21,58,71,89,3,15,43,63,1,7,26,38,42,69001-69009,69,73,74), "D.R. LYON",
                                              ifelse(NB_three$RegionCode%in%c(8,10,51,52,54,55,57,88,67,68,25,39,70,90),"D.R. NANCY",
                                                         ifelse(NB_three$RegionCode%in%c(91,92,93,77,78,94,95),"IDF(woParis)",
                                                                ifelse(NB_three$RegionCode%in%c(75001-75020,75),"PARIS",
                                                                   ifelse(NB_three$RegionCode==99, "AUTRE", "")))))))))


table(NB_three$region)

## keep only useful variables and rename them
NB_three_region=subset(NB_three,select=c(profilID, insurer,period,coverage,price,region))
names(NB_three_region)=c("profilID", "insurer","period","coverage","price","segment")

## ## find the top1 profile by segment
NB_three_region_top1=top1propor_segment(NB_three_region)
## calculate proportion
NB_three_region_top1$proportion=round((NB_three_region_top1$cumsum/NB_three_region_top1$cumsum2)*100)

## calculate profile number by each segment
## input: data of all_home2_region_top1, segment name, period
# profil_number(all_home2_region_top1, "region",name, month )

## outptu the graphs 
rankseg_output_segment(NB_three_region_top1, paste("region","NB"),PathNameseg)

## calculate profile number by each segment
profil_number_region=data.table(NB_three_region)
profil_number_region$ct=1
profil_number_region <- profil_number_region[,list(somme=sum(ct)), by = c("period","coverage","insurer","segment")]
write.table(profil_number_region, file=paste(PathNameseg,"profil_number_region.csv",sep="/"), col.names=TRUE,row.names=FALSE,sep=";",quote=FALSE)

NB_three_region_summary=data.table(NB_three_region)
NB_three_region_summary <- NB_three_region_summary[,list(mean=mean(price)), by = c("period","coverage","insurer","segment")]

write.table(NB_three_region_summary, file=paste(PathNameseg,"NB_three_region_summary.csv",sep="/"), col.names=TRUE,row.names=FALSE,sep=";",quote=FALSE)


# compare the new and old tarrif

data_player=NB_three[NB_three$insurer=="Direct Assurance",]

w1=data_player[data_player$period=="Y16M09"& data_player$insurer=="Direct Assurance",]
w2=data_player[data_player$period=="Y16M09_Mario"& data_player$insurer=="Direct Assurance",]

w12=merge(w1,w2, by=c("profilID","coverage","insurer"))
w12$delta=w12$price.y/w12$price.x-1
w12$delta=round(w12$delta*100,2)

w12=w12[w12$delta<300,]
# #The price difference is delta=w2price/w1price-1 in% : input data of one insurer and period   
# player_delta=price_changes(data_player,target_player,target_player,target_period1, target_period2)

# 
# player_delta=player_delta[player_delta$delta<50,]

summary(w12[w12$coverage=="Basic Coverage",]$delta)
summary(w12[w12$coverage=="Comfortable Coverage",]$delta)
summary(w12[w12$coverage=="PNO",]$delta)

w12_basic=w12[w12$coverage=="Basic Coverage",]
output_summary_csv(w12_basic)
graphics.off()
output_delta_distribution(w12_basic,"Basic Coverage",min(w12_basic$delta),max(w12_basic$delta),40)


w12_com=w12[w12$coverage=="Comfortable Coverage",]
output_summary_csv(w12_com)
graphics.off()
output_delta_distribution(w12_com,"Comfortable Coverage",min(w12_com$delta),max(w12_com$delta),40)

w12_PNO=w12[w12$coverage=="PNO",]
output_summary_csv(w12_PNO)
graphics.off()
output_delta_distribution(w12_PNO,"PNO",min(w12_PNO$delta),max(w12_PNO$delta),40)

# #######################################################concentre en IDF region
# ASSURLAND_HOME_DA_BNP1_rl=ASSURLAND_HOME_DA_BNP1[ASSURLAND_HOME_DA_BNP1$region%in%c("IDF(woParis)","PARIS") &ASSURLAND_HOME_DA_BNP1$period=="Y16M09",]
# 
# length(unique(ASSURLAND_HOME_DA_BNP1_rl[ASSURLAND_HOME_DA_BNP1_rl$occupanttype=="Owner",]$profilID))
# length(unique(ASSURLAND_HOME_DA_BNP1_rl[ASSURLAND_HOME_DA_BNP1_rl$occupanttype=="Tenant",]$profilID))
# 
# ## keep only useful variables and rename them
# ASSURLAND_HOME_DA_BNP1_rl=subset(ASSURLAND_HOME_DA_BNP1_rl,select=c(profilID, insurer,period,coverage,price,occupanttype))
# names(ASSURLAND_HOME_DA_BNP1_rl)=c("profilID", "insurer","period","coverage","price","segment")
# 
# ## ## find the top1 profile by segment
# all_home2_region_oc_top1=top1propor_segment(ASSURLAND_HOME_DA_BNP1_rl)
# ## calculate proportion
# all_home2_region_oc_top1$proportion=round((all_home2_region_oc_top1$cumsum/all_home2_region_oc_top1$cumsum2)*100)
# 
# ## calculate profile number by each segment
# ## input: data of all_home2_region_top1, segment name, period
# # profil_number(all_home2_region_top1, "region",name, month )
# 
# ## outptu the graphs 
# rankseg_output_segment(all_home2_region_oc_top1, paste("IDF_Occupanttype",name),PathNameseg)
NB_three$yearmonth=NB_three$period
price_gap_ovo_v2(NB_three,month,"Direct Assurance", "Pacifica")

## DA VS AcommeAssure
price_gap_ovo_v2(NB_three,month,"Direct Assurance", "Macif")

