### add the price of Macif and Pacifica

###################Analyses for BNP#####################
## define the scope of competitors
player=BNP_players
## the name for outputs
Name="BNP Natio"

## the input data: select only the scope for BNP
ASSURLAND_HOME_DA_BNP1=ASSURLAND_HOME_DA_BNP[ASSURLAND_HOME_DA_BNP$insurer%in%player,]

## input data--> BNP price with competitors prices
## output graphs: top1 ranking + ranking by players + price gap + mean of price gap 
source("./MRH_Report/analyses_top1_rankingbyplayer_pricgap.R")

month=c("Y16M06","Y16M09","Y16M09_Mario")


# price_gap_ovo(database,period,insurer0, insurer1): price gap=insurer0/insurer1-1
## input the database
##output the price gap graphs;  prce gap mean table; 
## princt the common profiles number for basic coverage and comfortable coverages


## BNP VS MMA
price_gap_ovo(ASSURLAND_HOME_DA_BNP,month,"BNP Natio", "MMA")

## BNP VS MAAF
price_gap_ovo(ASSURLAND_HOME_DA_BNP,month,"BNP Natio", "MAAF Assurances")

## BNP VS AcommeAssure
price_gap_ovo(ASSURLAND_HOME_DA_BNP,month,"BNP Natio", "AcommeAssure")

## BNP VS GMF
price_gap_ovo(ASSURLAND_HOME_DA_BNP,month,"BNP Natio", "GMF")



### price changes and DT #######

covfr=c("Basic Coverage" ,"Comfortable Coverage"  )
target_player= "Carrefour Assurances"
data=ASSURLAND_HOME_DA_BNP
target_period1="Y16M03"
target_period2="Y16M09"
source("./MRH_Report/price_distribution.R")

covfr=c("Comfortable Coverage")
factor=T
source("./MRH_Report/decision_tree.R")

######
covfr=c("Basic Coverage" ,"Comfortable Coverage"  )
target_player= "MAAF Assurances"
data=ASSURLAND_HOME_DA_BNP
target_period1="Y16M06"
target_period2="Y16M09"
source("./MRH_Report/price_distribution.R")

covfr=c("Basic Coverage" ,"Comfortable Coverage"  )
target_player= "MMA"
data=ASSURLAND_HOME_DA_BNP
target_period1="Y16M06"
target_period2="Y16M09"

source("./MRH_Report/price_distribution.R")

covfr=c("Comfortable Coverage"  )
source("./MRH_Report/decision_tree.R")



### segment anaysis for BNP Natio
## input--> name, player scope, data
## output: three segments analyses
name="BNP Natio"
player=BNP_players
month=unique(ASSURLAND_HOME_DA_BNP$period)
ASSURLAND_HOME_DA_BNP1=ASSURLAND_HOME_DA_BNP[ASSURLAND_HOME_DA_BNP$insurer%in%player, ]
source("./MRH_Report/segment_analyses.R")

