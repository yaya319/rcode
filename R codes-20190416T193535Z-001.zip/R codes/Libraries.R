# # installing/loading the package:
# if(!require(installr)) {
#   install.packages("installr"); require(installr)} #load / install+load installr
# 
# # using the package:
# updateR() # this will start the updating process of your R installation.  It will check for newer versions, and if one is available, will guide you through the decisions you'd need to make.



#### Load library ####
neededPacks = c("scales","ggplot2","scales", "plyr", "RColorBrewer", "data.table", "plyr", "reshape","stringr","gtools",
                "grid","chron","TTR","data.table", "RPostgreSQL","gridExtra","sqldf", "ggplot2","colorspace", "reshape2", "RDCOMClient", 
                "lme4", "doBy", "DBI", "xts","zoo","Matrix", "Rcpp","foreach", "parallel", "doParallel", "rJava", "xlsxjars", "xlsx", "dplyr", 
                "R2PPT","party","RGtk2","gWidgets", "devtools","magrittr","rattle", "rmarkdown")

for (packLoc in neededPacks) {
  if (!is.element(packLoc, installed.packages()[,1])) {
    install.packages(packLoc)
  }
  library(packLoc,character.only = TRUE)
}




### the grahps

wt=theme(panel.background = element_rect(fill = '#ffffff'),panel.grid.major = element_line(colour = '#dddddd'),panel.grid.minor = element_line(colour = '#eeeeee'),text = element_text(size=28))
wtsl=theme(panel.background = element_rect(fill = '#ffffff'),panel.grid.major = element_line(colour = '#dddddd'),panel.grid.minor = element_line(colour = '#eeeeee'),text = element_text(size=28), axis.text.x = element_text(angle = 90, hjust = 1), legend.background = element_rect(fill = '#ffffff'), legend.key = element_rect(fill = '#ffffff'))
wtl=theme(panel.background = element_rect(fill = '#ffffff'),panel.grid.major = element_line(colour = '#dddddd'),panel.grid.minor = element_line(colour = '#eeeeee'),text = element_text(size=34), axis.text.x = element_text(angle = 90, hjust = 1),legend.background = element_rect(fill = '#ffffff'), legend.key = element_rect(fill = '#ffffff'))
wtsl1=theme(panel.background = element_rect(fill = '#ffffff'),panel.grid.major = element_line(colour = '#dddddd'),panel.grid.minor = element_line(colour = '#eeeeee'),text = element_text(size=32), axis.text.x = element_text(angle = 0, hjust =0.5,vjust=1 ), legend.background = element_rect(fill = '#ffffff'), legend.key = element_rect(fill = '#ffffff'))
